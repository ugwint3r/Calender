#!/usr/bin/env python3
"""CalendarPro launcher icons - a premium calendar emblem on a deep gradient."""
import os, math
from PIL import Image, ImageDraw

ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "android_app", "res")
SS = 8

DENS = {"mdpi": 48, "hdpi": 72, "xhdpi": 96, "xxhdpi": 144, "xxxhdpi": 192}
ADAPT = {
    "mdpi": (108, 72), "hdpi": (162, 108), "xhdpi": (216, 144),
    "xxhdpi": (324, 216), "xxxhdpi": (432, 288),
}
TOP = (32, 22, 92)
MID = (18, 14, 58)
BOT = (6, 5, 18)
ACCENT = (232, 190, 106, 255)
ACCENT_SOFT = (255, 226, 168, 255)
PAPER = (245, 242, 252, 255)
INK = (24, 20, 46, 255)


def gradient(size):
    img = Image.new("RGB", (1, size))
    d = ImageDraw.Draw(img)
    for y in range(size):
        t = y / max(1, size - 1)
        if t < 0.5:
            k = t / 0.5
            c = tuple(int(TOP[i] + (MID[i] - TOP[i]) * k) for i in range(3))
        else:
            k = (t - 0.5) / 0.5
            c = tuple(int(MID[i] + (BOT[i] - MID[i]) * k) for i in range(3))
        d.point((0, y), fill=c)
    return img.resize((size, size))


def emblem(size):
    img = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    u = size / 100.0
    cx = cy = size / 2.0
    w = 54 * u
    h = 52 * u
    x0, y0 = cx - w / 2, cy - h / 2 + 3 * u
    x1, y1 = cx + w / 2, cy + h / 2 + 3 * u
    # rounded calendar body
    rad = 9 * u
    d.rounded_rectangle([x0, y0, x1, y1], radius=rad, fill=PAPER,
                        outline=INK, width=max(2, int(1.6 * u)))
    # header band
    d.rounded_rectangle([x0, y0, x1, y0 + 13 * u], radius=rad, fill=ACCENT)
    d.rectangle([x0, y0 + 8 * u, x1, y0 + 13 * u], fill=ACCENT)
    # rings
    for fx in (0.32, 0.68):
        rx = x0 + w * fx
        d.rounded_rectangle([rx - 2.2 * u, y0 - 6 * u, rx + 2.2 * u, y0 + 6 * u],
                            radius=2.2 * u, fill=ACCENT_SOFT, outline=INK, width=max(1, int(1.0 * u)))
    # grid dots
    cols, rows = 4, 3
    gx0, gy0 = x0 + 7 * u, y0 + 19 * u
    stepx = (w - 14 * u) / (cols - 1)
    stepy = (h - 27 * u) / (rows - 1)
    for r in range(rows):
        for c in range(cols):
            px = gx0 + c * stepx
            py = gy0 + r * stepy
            rr = 2.6 * u
            col = ACCENT if (r == 1 and c == 2) else INK
            d.ellipse([px - rr, py - rr, px + rr, py + rr], fill=col)
    return img


def main():
    for name, px in DENS.items():
        folder = os.path.join(ROOT, "mipmap-" + name)
        os.makedirs(folder, exist_ok=True)
        n = int(px * SS)
        base = gradient(n).convert("RGBA")
        base.alpha_composite(emblem(n))
        base.resize((px, px), Image.LANCZOS).save(os.path.join(folder, "ic_launcher.png"))

        rnd = Image.new("RGBA", (n, n), (0, 0, 0, 0))
        mask = Image.new("L", (n, n), 0)
        ImageDraw.Draw(mask).ellipse([0, 0, n - 1, n - 1], fill=255)
        rnd.paste(base, (0, 0), mask)
        rnd.resize((px, px), Image.LANCZOS).save(os.path.join(folder, "ic_launcher_round.png"))

    for name, (bpx, fpx) in ADAPT.items():
        folder = os.path.join(ROOT, "mipmap-" + name)
        os.makedirs(folder, exist_ok=True)
        gradient(bpx).save(os.path.join(folder, "ic_launcher_background.png"))
        fg = emblem(int(fpx * SS)).resize((fpx, fpx), Image.LANCZOS)
        fg.save(os.path.join(folder, "ic_launcher_foreground.png"))

    print("icons written to", ROOT)


if __name__ == "__main__":
    main()
