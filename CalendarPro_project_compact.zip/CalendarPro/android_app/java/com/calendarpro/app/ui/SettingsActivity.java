package com.calendarpro.app.ui;

import android.app.Activity;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;

import com.calendarpro.app.R;
import com.calendarpro.app.data.Cal;
import com.calendarpro.app.data.Cfg;
import com.calendarpro.app.data.Reminder;
import com.calendarpro.app.util.Fmt;
import com.calendarpro.app.util.Theme;

public class SettingsActivity extends Activity {

    private LinearLayout content;

    @Override
    protected void onCreate(Bundle b) {
        Theme.apply(this);
        super.onCreate(b);
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Theme.bg());
        root.addView(new GlowView(this), new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        ScrollView scroll = new ScrollView(this);
        scroll.setVerticalScrollBarEnabled(false);
        content = Ui.col(this);
        Ui.pad(content, 14, 6, 14, 40);
        scroll.addView(content);
        root.addView(scroll, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        setContentView(root);
        build();
    }

    private void build() {
        content.removeAllViews();
        buildTop();
        buildAppearance();
        buildCalendar();
        buildHolidays();
        buildReminder();
        buildAbout();
    }

    private void buildTop() {
        LinearLayout top = Ui.row(this);
        ImageView back = Ui.icon(this, R.drawable.ic_back, 40, Theme.text());
        back.setPadding(Ui.dp(this, 8), Ui.dp(this, 8), Ui.dp(this, 8), Ui.dp(this, 8));
        back.setClickable(true);
        back.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { finish(); }
        });
        top.addView(back);
        LinearLayout titles = Ui.col(this);
        titles.addView(Ui.bold(Ui.text(this, "تنظیمات", 18, Theme.text())));
        titles.addView(Ui.text(this, "شخصی‌سازی تقویم پرو", 11, Theme.sub()));
        LinearLayout.LayoutParams tlp = Ui.lp(0, ViewGroup.LayoutParams.WRAP_CONTENT);
        tlp.weight = 1;
        tlp.leftMargin = Ui.dp(this, 4);
        top.addView(titles, tlp);
        LinearLayout.LayoutParams lp = Ui.lp(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.bottomMargin = Ui.dp(this, 10);
        content.addView(top, lp);
    }

    private void buildAppearance() {
        content.addView(Ui.sectionTitle(this, "ظاهر"));

        LinearLayout themeCard = Ui.card(this);
        themeCard.addView(label("پوسته"));
        LinearLayout seg = Ui.row(this);
        String[] names = {"تاریک", "روشن", "سیستمی"};
        for (int i = 0; i < 3; i++) {
            final int idx = i;
            TextView t = Ui.text(this, names[i], 14, i == Cfg.theme() ? 0xFF1A1206 : Theme.sub());
            t.setGravity(Gravity.CENTER);
            if (i == Cfg.theme()) {
                Ui.bold(t);
                t.setBackground(Ui.bg(Theme.accent(), 14, this));
            }
            Ui.pad(t, 0, 9, 0, 9);
            LinearLayout.LayoutParams lp = Ui.lp(0, ViewGroup.LayoutParams.WRAP_CONTENT);
            lp.weight = 1;
            t.setLayoutParams(lp);
            t.setClickable(true);
            t.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) { Cfg.theme(idx); recreate(); }
            });
            seg.addView(t);
        }
        LinearLayout.LayoutParams slp = Ui.lp(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        slp.topMargin = Ui.dp(this, 8);
        seg.setBackground(Ui.bg(Theme.card2(), 16, this));
        int sp = Ui.dp(this, 4);
        seg.setPadding(sp, sp, sp, sp);
        themeCard.addView(seg, slp);
        content.addView(themeCard);

        LinearLayout accentCard = Ui.card(this);
        accentCard.addView(label("رنگ لهجه"));
        LinearLayout sw = Ui.row(this);
        for (int i = 0; i < Theme.ACCENTS.length; i++) {
            final int idx = i;
            View dot = new View(this);
            dot.setBackground(Ui.ring(Theme.ACCENTS[i], i == Cfg.accent() ? 0xFFFFFFFF : 0x00000000,
                    i == Cfg.accent() ? 2f : 0f, this));
            LinearLayout.LayoutParams lp = Ui.lp(Ui.dp(this, 30), Ui.dp(this, 30));
            lp.rightMargin = Ui.dp(this, 8);
            lp.bottomMargin = Ui.dp(this, 4);
            dot.setLayoutParams(lp);
            dot.setClickable(true);
            dot.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) { Cfg.accent(idx); recreate(); }
            });
            sw.addView(dot);
        }
        accentCard.addView(sw);
        content.addView(accentCard);

        LinearLayout digCard = Ui.card(this);
        digCard.addView(label("شکل ارقام"));
        LinearLayout digRow = Ui.row(this);
        digRow.addView(chip("۱۲۳ فارسی", Cfg.digits() == 0, new Runnable() {
            public void run() { Cfg.digits(0); recreate(); }
        }));
        digRow.addView(chip("123 لاتین", Cfg.digits() == 1, new Runnable() {
            public void run() { Cfg.digits(1); recreate(); }
        }));
        digCard.addView(digRow);
        content.addView(digCard);
    }

    private void buildCalendar() {
        content.addView(Ui.sectionTitle(this, "تقویم"));

        LinearLayout primaryCard = Ui.card(this);
        primaryCard.addView(label("تقویم اصلی"));
        LinearLayout row = Ui.row(this);
        int n = 0;
        for (final int sys : Cal.PRIMARY) {
            row.addView(chip(Cal.sysShort(sys), sys == Cfg.primaryCal(), new Runnable() {
                public void run() { Cfg.primaryCal(sys); build(); }
            }));
            if (++n % 3 == 0) {
                primaryCard.addView(row);
                row = Ui.row(this);
            }
        }
        if (row.getChildCount() > 0) primaryCard.addView(row);
        content.addView(primaryCard);

        LinearLayout weekCard = Ui.card(this);
        weekCard.addView(label("شروع هفته"));
        LinearLayout wr = Ui.row(this);
        String[] wd = {"شنبه", "یکشنبه", "دوشنبه"};
        for (int i = 0; i < 3; i++) {
            final int idx = i;
            wr.addView(chip(wd[i], Cfg.weekStart() == idx, new Runnable() {
                public void run() { Cfg.weekStart(idx); build(); }
            }));
        }
        weekCard.addView(wr);
        content.addView(weekCard);

        LinearLayout offCard = Ui.card(this);
        offCard.addView(label("تصحیح تقویم قمری"));
        LinearLayout orow = Ui.row(this);
        orow.addView(step("−", new Runnable() {
            public void run() { Cfg.hijriOffset(Math.max(-3, Cfg.hijriOffset() - 1)); build(); }
        }));
        TextView val = Ui.bold(Ui.text(this, Fmt.fa((Cfg.hijriOffset() > 0 ? "+" : "") + Cfg.hijriOffset()) + " روز",
                16, Theme.text()));
        val.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams vlp = Ui.lp(0, ViewGroup.LayoutParams.WRAP_CONTENT);
        vlp.weight = 1;
        orow.addView(val, vlp);
        orow.addView(step("＋", new Runnable() {
            public void run() { Cfg.hijriOffset(Math.min(3, Cfg.hijriOffset() + 1)); build(); }
        }));
        oftCardAdd(offCard, orow);
        content.addView(offCard);
    }

    private void oftCardAdd(LinearLayout card, View v) {
        LinearLayout.LayoutParams lp = Ui.lp(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = Ui.dp(this, 8);
        card.addView(v, lp);
    }

    private void buildHolidays() {
        content.addView(Ui.sectionTitle(this, "نمایش"));
        LinearLayout card = Ui.card(this);
        card.addView(switchRow("تقویم‌های دوم روی روزها", Cfg.secondary(), new Toggle() {
            public void on(boolean v) { Cfg.secondary(v); build(); }
        }));
        card.addView(Ui.divider(this, 0.6f));
        card.addView(switchRow("نشانه‌گذاری تعطیلات", Cfg.showHolidays(), new Toggle() {
            public void on(boolean v) { Cfg.showHolidays(v); build(); }
        }));
        card.addView(Ui.divider(this, 0.6f));
        card.addView(switchRow("پس‌زمینه‌ی درخشان", Cfg.glow(), new Toggle() {
            public void on(boolean v) { Cfg.glow(v); build(); }
        }));
        content.addView(card);
    }

    private void buildReminder() {
        content.addView(Ui.sectionTitle(this, "یادآور"));
        LinearLayout card = Ui.card(this);
        card.addView(switchRow("یادآور روزانه‌ی رویدادها", Cfg.remind(), new Toggle() {
            public void on(boolean v) { Cfg.remind(v); Reminder.apply(SettingsActivity.this); build(); }
        }));
        card.addView(Ui.divider(this, 0.6f));

        LinearLayout timeRow = Ui.row(this);
        Ui.pad(timeRow, 2, 12, 2, 4);
        timeRow.addView(Ui.text(this, "ساعت یادآور", 14, Theme.text()));
        timeRow.addView(Ui.spacer(this, 1));
        timeRow.addView(step("−", new Runnable() {
            public void run() { shiftTime(-15); }
        }));
        TextView tv = Ui.bold(Ui.text(this, Fmt.clock(Cfg.notifyHour(), Cfg.notifyMinute()), 16, Theme.accent()));
        tv.setGravity(Gravity.CENTER);
        Ui.pad(tv, 10, 0, 10, 0);
        timeRow.addView(tv);
        timeRow.addView(step("＋", new Runnable() {
            public void run() { shiftTime(15); }
        }));
        card.addView(timeRow);

        TextView hint = Ui.text(this, "یادآور شامل تعطیلات و رویدادهای همان روز است.",
                11, Theme.sub());
        Ui.pad(hint, 2, 4, 2, 2);
        card.addView(hint);
        content.addView(card);
    }

    private void shiftTime(int delta) {
        int total = Cfg.notifyHour() * 60 + Cfg.notifyMinute() + delta;
        total = ((total % 1440) + 1440) % 1440;
        Cfg.notifyTime(total / 60, total % 60);
        Reminder.apply(this);
        build();
    }

    private void buildAbout() {
        content.addView(Ui.sectionTitle(this, "درباره"));
        LinearLayout card = Ui.card(this);
        card.addView(label("تقویم پرو — نسخهٔ ۱٫۰"));
        TextView t = Ui.text(this,
                "پشتیبانی از گاه‌شماری‌های میلادی، هجری شمسی، هجری قمری، یولیانی، عبری و قبطی، " +
                        "همراه با نمايش همه‌ی اعصار و رویدادهای شخصی.",
                13, Theme.sub());
        t.setLineSpacing(Ui.dp(this, 3), 1f);
        Ui.pad(t, 2, 6, 2, 4);
        card.addView(t);
        content.addView(card);

        TextView reset = Ui.text(this, "بازنشانی همه‌ی تنظیمات و رویدادها", 14, Theme.holiday());
        Ui.pad(reset, 4, 10, 4, 4);
        reset.setClickable(true);
        reset.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                new android.app.AlertDialog.Builder(SettingsActivity.this)
                        .setTitle("بازنشانی")
                        .setMessage("همه‌ی رویدادها و تنظیمات حذف شوند؟")
                        .setPositiveButton("بله", new android.content.DialogInterface.OnClickListener() {
                            public void onClick(android.content.DialogInterface d, int w) {
                                com.calendarpro.app.App.p.edit().clear().apply();
                                Reminder.cancel(SettingsActivity.this);
                                recreate();
                            }
                        })
                        .setNegativeButton("خیر", null)
                        .show();
            }
        });
        content.addView(reset);
    }

    // ------------------------------------------------------------ helpers

    private TextView label(String s) {
        TextView t = Ui.text(this, s, 14, Theme.text());
        Ui.pad(t, 2, 2, 2, 6);
        return t;
    }

    private View chip(String s, boolean on, final Runnable onClick) {
        TextView t = Ui.text(this, s, 13, on ? 0xFF1A1206 : Theme.text());
        Ui.pad(t, 14, 8, 14, 8);
        LinearLayout.LayoutParams lp = Ui.lp(ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.rightMargin = Ui.dp(this, 8);
        lp.bottomMargin = Ui.dp(this, 6);
        t.setLayoutParams(lp);
        t.setBackground(Ui.ripple(this, Ui.bg(on ? Theme.accent() : Theme.card2(), 18, this),
                Theme.accentSoft()));
        if (on) Ui.bold(t);
        t.setClickable(true);
        t.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { onClick.run(); }
        });
        return t;
    }

    private TextView step(String s, final Runnable onClick) {
        TextView t = Ui.bold(Ui.text(this, s, 18, Theme.text()));
        t.setGravity(Gravity.CENTER);
        t.setBackground(Ui.ripple(this, Ui.circle(Theme.card2()), Theme.accentSoft()));
        t.setLayoutParams(Ui.lp(Ui.dp(this, 38), Ui.dp(this, 38)));
        t.setClickable(true);
        t.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { onClick.run(); }
        });
        return t;
    }

    private interface Toggle { void on(boolean v); }

    private View switchRow(String title, boolean value, final Toggle t) {
        LinearLayout row = Ui.row(this);
        Ui.pad(row, 2, 8, 2, 8);
        row.addView(Ui.text(this, title, 14, Theme.text()));
        row.addView(Ui.spacer(this, 1));
        Switch sw = new Switch(this);
        sw.setChecked(value);
        sw.setOnCheckedChangeListener(new android.widget.CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(android.widget.CompoundButton b, boolean v) { t.on(v); }
        });
        row.addView(sw);
        return row;
    }
}
