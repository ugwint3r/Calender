package com.calendarpro.app.ui;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.view.View;

import com.calendarpro.app.util.Theme;

/** Soft accent glow behind the content. */
public class GlowView extends View {
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);

    public GlowView(Context c) {
        super(c);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        if (!com.calendarpro.app.data.Cfg.glow()) return;
        float w = getWidth(), h = getHeight();
        int accent = Theme.accent();
        int top = Ui.withAlpha(accent, Theme.dark ? 0x2A : 0x1C);
        int clear = Ui.withAlpha(accent, 0);
        p.setShader(new RadialGradient(w * 0.72f, h * 0.06f,
                Math.max(w * 0.9f, h * 0.42f),
                new int[]{top, clear, clear},
                new float[]{0f, 0.45f, 1f}, Shader.TileMode.CLAMP));
        canvas.drawRect(0, 0, w, h, p);
        p.setShader(null);
    }
}
