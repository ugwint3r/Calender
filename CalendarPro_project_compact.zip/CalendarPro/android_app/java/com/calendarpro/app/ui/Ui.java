package com.calendarpro.app.ui;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.calendarpro.app.util.Theme;

public final class Ui {
    private Ui() {}

    public static int dp(Context c, float v) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, c.getResources().getDisplayMetrics());
    }

    public static int sp(Context c, float v) { return dp(c, v); }

    // ------------------------------------------------------------ drawables

    public static GradientDrawable bg(int color, float radiusDp, Context c) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(c, radiusDp));
        return g;
    }

    public static GradientDrawable stroke(int color, int strokeColor, float radiusDp, Context c) {
        GradientDrawable g = bg(color, radiusDp, c);
        g.setStroke(dp(c, 1), strokeColor);
        return g;
    }

    public static GradientDrawable gradient(int top, int bottom, float radiusDp, Context c) {
        GradientDrawable g = new GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM, new int[]{top, bottom});
        g.setCornerRadius(dp(c, radiusDp));
        return g;
    }

    public static GradientDrawable gradient(GradientDrawable.Orientation o, int[] colors,
                                            float radiusDp, Context c) {
        GradientDrawable g = new GradientDrawable(o, colors);
        g.setCornerRadius(dp(c, radiusDp));
        return g;
    }

    public static GradientDrawable oval(int a, int b) {
        GradientDrawable g = new GradientDrawable(
                GradientDrawable.Orientation.TL_BR, new int[]{a, b});
        g.setShape(GradientDrawable.OVAL);
        return g;
    }

    public static GradientDrawable circle(int color) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setShape(GradientDrawable.OVAL);
        return g;
    }

    public static GradientDrawable ring(int color, int strokeColor, float widthDp, Context c) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setShape(GradientDrawable.OVAL);
        g.setStroke(Math.max(1, dp(c, widthDp)), strokeColor);
        return g;
    }

    public static RippleDrawable ripple(Context c, Drawable content, int rippleColor) {
        return new RippleDrawable(ColorStateList.valueOf(rippleColor), content, null);
    }

    public static ColorDrawable color(int c) { return new ColorDrawable(c); }

    // ------------------------------------------------------------ widgets

    public static TextView text(Context c, CharSequence s, float sp, int color) {
        TextView t = new TextView(c);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        return t;
    }

    public static TextView bold(TextView t) {
        t.setTypeface(t.getTypeface(), android.graphics.Typeface.BOLD);
        return t;
    }

    public static LinearLayout row(Context c) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL);
        return l;
    }

    public static LinearLayout col(Context c) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }

    public static ImageView icon(Context c, int resId, float sizeDp, int color) {
        ImageView iv = new ImageView(c);
        iv.setImageResource(resId);
        iv.setColorFilter(color);
        int s = dp(c, sizeDp);
        iv.setLayoutParams(new LinearLayout.LayoutParams(s, s));
        return iv;
    }

    public static View spacer(Context c, float weight) {
        View v = new View(c);
        v.setLayoutParams(new LinearLayout.LayoutParams(0, 1, weight));
        return v;
    }

    public static View gap(Context c, float hDp) {
        View v = new View(c);
        v.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(c, hDp)));
        return v;
    }

    public static void margins(View v, int l, int t, int r, int b) {
        ViewGroup.MarginLayoutParams p = (ViewGroup.MarginLayoutParams) v.getLayoutParams();
        if (p == null) return;
        p.setMargins(dp(v.getContext(), l), dp(v.getContext(), t),
                dp(v.getContext(), r), dp(v.getContext(), b));
        v.setLayoutParams(p);
    }

    public static LinearLayout.LayoutParams lp(int w, int h) {
        return new LinearLayout.LayoutParams(w, h);
    }

    public static void pad(View v, int l, int t, int r, int b) {
        v.setPadding(dp(v.getContext(), l), dp(v.getContext(), t),
                dp(v.getContext(), r), dp(v.getContext(), b));
    }

    public static View divider(Context c, float heightDp) {
        View v = new View(c);
        v.setBackgroundColor(Theme.line());
        v.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, Math.max(1, dp(c, heightDp))));
        return v;
    }

    // ------------------------------------------------------------ composites

    public static LinearLayout card(Context c) {
        LinearLayout l = col(c);
        l.setBackground(bg(Theme.card(), 20, c));
        int p = dp(c, 16);
        l.setPadding(p, p, p, p);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.bottomMargin = dp(c, 12);
        l.setLayoutParams(lp);
        return l;
    }

    public static LinearLayout.LayoutParams cardLp(Context c) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.bottomMargin = dp(c, 12);
        return lp;
    }

    public static TextView sectionTitle(Context c, String s) {
        TextView t = text(c, s, 13, Theme.accent());
        t.setPadding(dp(c, 4), dp(c, 14), 0, dp(c, 8));
        return t;
    }

    public static LinearLayout chip(Context c, CharSequence label, boolean selected) {
        LinearLayout l = row(c);
        l.setBackground(ripple(c, bg(selected ? Theme.accent() : Theme.card2(), 18, c), Theme.accentSoft()));
        int px = dp(c, 14), py = dp(c, 8);
        l.setPadding(px, py, px, py);
        TextView t = text(c, label, 13, selected ? 0xFF1A1206 : Theme.text());
        l.addView(t);
        l.setTag(t);
        return l;
    }

    public static void chipSetSelected(LinearLayout chip, boolean selected) {
        chip.setBackground(ripple(chip.getContext(),
                bg(selected ? Theme.accent() : Theme.card2(), 18, chip.getContext()),
                Theme.accentSoft()));
        Object tag = chip.getTag();
        if (tag instanceof TextView) ((TextView) tag).setTextColor(selected ? 0xFF1A1206 : Theme.text());
    }

    public static ProgressBar bar(Context c, int progress) {
        ProgressBar pb = new ProgressBar(c, null, android.R.attr.progressBarStyleHorizontal);
        pb.setMax(100);
        pb.setProgress(progress);
        pb.setProgressTintList(ColorStateList.valueOf(Theme.accent()));
        pb.setProgressBackgroundTintList(ColorStateList.valueOf(Theme.line()));
        pb.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(c, 6)));
        return pb;
    }

    // ------------------------------------------------------------ colors

    public static int blend(int c1, int c2, float t) {
        int a = (int) (((c1 >>> 24) & 0xFF) * (1 - t) + ((c2 >>> 24) & 0xFF) * t);
        int r = (int) (((c1 >> 16) & 0xFF) * (1 - t) + ((c2 >> 16) & 0xFF) * t);
        int g = (int) (((c1 >> 8) & 0xFF) * (1 - t) + ((c2 >> 8) & 0xFF) * t);
        int b = (int) ((c1 & 0xFF) * (1 - t) + (c2 & 0xFF) * t);
        return (a << 24) | (r << 16) | (g << 8) | b;
    }

    public static int lighten(int c, float t) { return blend(c, 0xFFFFFFFF, t); }
    public static int darken(int c, float t) { return blend(c, 0xFF000000, t); }
    public static int withAlpha(int c, int a) { return (c & 0x00FFFFFF) | (a << 24); }
}
