package com.calendarpro.app.ui;

import android.app.Activity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import com.calendarpro.app.R;
import com.calendarpro.app.data.Cal;
import com.calendarpro.app.data.Event;
import com.calendarpro.app.data.Reminder;
import com.calendarpro.app.data.Store;
import com.calendarpro.app.util.Fmt;
import com.calendarpro.app.util.Theme;

import java.util.ArrayList;
import java.util.List;

public class EventsActivity extends Activity {

    private LinearLayout content;
    private long today;

    @Override
    protected void onCreate(Bundle b) {
        Theme.apply(this);
        super.onCreate(b);
        today = Cal.todayJdn();

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Theme.bg());
        root.addView(new GlowView(this), new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        ScrollView scroll = new ScrollView(this);
        scroll.setVerticalScrollBarEnabled(false);
        content = Ui.col(this);
        Ui.pad(content, 14, 6, 14, 90);
        scroll.addView(content);
        root.addView(scroll, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        ImageView fab = Ui.icon(this, R.drawable.ic_plus, 30, 0xFF1A1206);
        fab.setPadding(Ui.dp(this, 16), Ui.dp(this, 16), Ui.dp(this, 16), Ui.dp(this, 16));
        fab.setBackground(Ui.ripple(this, Ui.circle(Theme.accent()), Theme.accentSoft()));
        FrameLayout.LayoutParams flp = new FrameLayout.LayoutParams(
                Ui.dp(this, 62), Ui.dp(this, 62));
        flp.gravity = Gravity.BOTTOM | Gravity.END;
        flp.bottomMargin = Ui.dp(this, 24);
        flp.rightMargin = Ui.dp(this, 20);
        fab.setLayoutParams(flp);
        fab.setClickable(true);
        fab.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                EventDialog.show(EventsActivity.this, today, null, new Runnable() {
                    public void run() { build(); Reminder.apply(EventsActivity.this); }
                });
            }
        });
        root.addView(fab);

        setContentView(root);
        build();
    }

    @Override
    protected void onResume() {
        super.onResume();
        build();
    }

    private void build() {
        content.removeAllViews();
        buildTop();
        List<Event> all = Store.all();
        if (all.isEmpty()) {
            LinearLayout card = Ui.card(this);
            card.addView(Ui.text(this, "هنوز رویدادی ثبت نشده است.", 15, Theme.text()));
            card.addView(Ui.text(this, "برای افزودن، دکمه‌ی + را بزنید یا روی روزی در تقویم نگه دارید.",
                    13, Theme.sub()));
            content.addView(card);
            return;
        }

        long lastJdn = Long.MIN_VALUE;
        List<Event> upcoming = new ArrayList<>();
        List<Event> past = new ArrayList<>();
        for (Event e : all) {
            if (e.jdn >= today) upcoming.add(e);
            else past.add(e);
        }
        if (!upcoming.isEmpty()) {
            content.addView(Ui.sectionTitle(this, "پیش‌رو"));
            for (Event e : upcoming) lastJdn = eventCard(e, lastJdn);
        }
        if (!past.isEmpty()) {
            content.addView(Ui.sectionTitle(this, "گذشته"));
            for (Event e : past) lastJdn = eventCard(e, lastJdn);
        }
    }

    private long eventCard(Event e, long lastJdn) {
        if (e.jdn != lastJdn) {
            LinearLayout head = Ui.row(this);
            Ui.pad(head, 4, 10, 4, 4);
            head.addView(Ui.text(this, Cal.format(Cal.JALALI, e.jdn), 14, Theme.accent()));
            head.addView(Ui.spacer(this, 1));
            head.addView(Ui.text(this, Cal.WEEK[Cal.week(e.jdn)] + " • " + Fmt.rel(today, e.jdn),
                    12, Theme.sub()));
            content.addView(head);
        }
        LinearLayout card = Ui.card(this);
        LinearLayout r = Ui.row(this);
        LinearLayout col = Ui.col(this);
        col.addView(Ui.bold(Ui.text(this, e.title, 16, Theme.text())));
        if (!e.note.isEmpty()) col.addView(Ui.text(this, e.note, 13, Theme.sub()));
        LinearLayout.LayoutParams clp = Ui.lp(0, ViewGroup.LayoutParams.WRAP_CONTENT);
        clp.weight = 1;
        r.addView(col, clp);
        r.addView(Ui.text(this, e.allDay() ? "تمام روز" : Fmt.clock(e.minutes), 13, Theme.accent()));
        card.addView(r);
        card.setClickable(true);
        card.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                EventDialog.show(EventsActivity.this, e.jdn, e, new Runnable() {
                    public void run() { build(); Reminder.apply(EventsActivity.this); }
                });
            }
        });
        content.addView(card);
        return e.jdn;
    }

    private void buildTop() {
        LinearLayout top = Ui.row(this);
        ImageView back = Ui.icon(this, R.drawable.ic_back, 40, Theme.text());
        back.setPadding(Ui.dp(this, 8), Ui.dp(this, 8), Ui.dp(this, 8), Ui.dp(this, 8));
        back.setClickable(true);
        back.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { finish(); }
        });
        top.addView(back);
        LinearLayout titles = Ui.col(this);
        titles.addView(Ui.bold(Ui.text(this, "رویدادها", 18, Theme.text())));
        titles.addView(Ui.text(this, Fmt.fa(Store.all().size()) + " رویداد ثبت‌شده", 11, Theme.sub()));
        LinearLayout.LayoutParams tlp = Ui.lp(0, ViewGroup.LayoutParams.WRAP_CONTENT);
        tlp.weight = 1;
        tlp.leftMargin = Ui.dp(this, 4);
        top.addView(titles, tlp);
        LinearLayout.LayoutParams lp = Ui.lp(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.bottomMargin = Ui.dp(this, 10);
        content.addView(top, lp);
    }
}
