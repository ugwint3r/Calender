package com.calendarpro.app.ui;

import android.app.Activity;
import android.content.Intent;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import com.calendarpro.app.R;
import com.calendarpro.app.data.Cal;
import com.calendarpro.app.data.Cfg;
import com.calendarpro.app.data.Event;
import com.calendarpro.app.data.Holidays;
import com.calendarpro.app.data.Reminder;
import com.calendarpro.app.data.Store;
import com.calendarpro.app.util.Fmt;
import com.calendarpro.app.util.Theme;

import java.util.List;

public class DayActivity extends Activity {

    private long jdn;
    private long today;
    private LinearLayout content;
    private ScrollView scroll;

    @Override
    protected void onCreate(Bundle b) {
        Theme.apply(this);
        super.onCreate(b);
        today = Cal.todayJdn();
        jdn = getIntent().getLongExtra("jdn", today);

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Theme.bg());
        root.addView(new GlowView(this), new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        scroll = new ScrollView(this);
        scroll.setVerticalScrollBarEnabled(false);
        content = Ui.col(this);
        Ui.pad(content, 14, 6, 14, 40);
        scroll.addView(content);
        root.addView(scroll, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        setContentView(root);
        build();
    }

    private void build() {
        content.removeAllViews();
        buildTop();
        buildHero();
        buildAllCalendars();
        buildEvents();
        buildActions();
    }

    private void buildTop() {
        LinearLayout top = Ui.row(this);
        ImageView back = Ui.icon(this, R.drawable.ic_back, 40, Theme.text());
        back.setPadding(Ui.dp(this, 8), Ui.dp(this, 8), Ui.dp(this, 8), Ui.dp(this, 8));
        back.setClickable(true);
        back.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { finish(); }
        });
        top.addView(back);
        TextView t = Ui.bold(Ui.text(this, "جزئیات روز", 18, Theme.text()));
        LinearLayout.LayoutParams tlp = Ui.lp(0, ViewGroup.LayoutParams.WRAP_CONTENT);
        tlp.weight = 1;
        tlp.leftMargin = Ui.dp(this, 4);
        top.addView(t, tlp);
        top.addView(iconButton(R.drawable.ic_globe, new Runnable() {
            public void run() {
                startActivity(new Intent(DayActivity.this, ErasActivity.class).putExtra("jdn", jdn));
            }
        }));
        LinearLayout.LayoutParams lp = Ui.lp(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.bottomMargin = Ui.dp(this, 10);
        content.addView(top, lp);
    }

    private ImageView iconButton(int res, final Runnable onClick) {
        ImageView iv = Ui.icon(this, res, 40, Theme.text());
        iv.setPadding(Ui.dp(this, 8), Ui.dp(this, 8), Ui.dp(this, 8), Ui.dp(this, 8));
        iv.setBackground(Ui.ripple(this, Ui.bg(0x00000000, 22, this), Theme.accentSoft()));
        iv.setClickable(true);
        iv.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { onClick.run(); }
        });
        return iv;
    }

    private void buildHero() {
        LinearLayout hero = Ui.col(this);
        int a = Theme.accent();
        hero.setBackground(Ui.gradient(GradientDrawable.Orientation.TL_BR, new int[]{
                Ui.withAlpha(a, Theme.dark ? 0xFF : 0xFF), Ui.darken(a, 0.5f)}, 24, this));
        int p = Ui.dp(this, 18);
        hero.setPadding(p, p, p, p);

        LinearLayout nav = Ui.row(this);
        nav.addView(arrow(R.drawable.ic_back, -1));
        nav.addView(Ui.spacer(this, 1));
        TextView badge = Ui.text(this, Fmt.rel(today, jdn), 13, 0xFF1A1206);
        Ui.pad(badge, 12, 6, 12, 6);
        badge.setBackground(Ui.bg(0x55FFFFFF, 14, this));
        nav.addView(badge);
        nav.addView(Ui.spacer(this, 1));
        nav.addView(arrow(R.drawable.ic_chev_right, 1));
        hero.addView(nav);

        TextView big = Ui.bold(Ui.text(this, Fmt.num(Cal.fromJdn(Cal.JALALI, jdn)[2]), 46, 0xFFFFFFFF));
        big.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams blp = Ui.lp(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        blp.topMargin = Ui.dp(this, 8);
        hero.addView(big, blp);
        TextView sub = Ui.text(this, Cal.WEEK[Cal.week(jdn)] + "  •  " +
                Cal.format(Cal.JALALI, jdn), 14, 0xE6FFFFFF);
        sub.setGravity(Gravity.CENTER);
        hero.addView(sub);
        TextView sub2 = Ui.text(this, Cal.format(Cal.GREGORIAN, jdn), 12, 0xCCFFFFFF);
        sub2.setGravity(Gravity.CENTER);
        hero.addView(sub2);

        content.addView(hero, Ui.cardLp(this));
    }

    private ImageView arrow(int res, final int delta) {
        ImageView iv = Ui.icon(this, res, 28, 0xFFFFFFFF);
        iv.setPadding(Ui.dp(this, 6), Ui.dp(this, 6), Ui.dp(this, 6), Ui.dp(this, 6));
        iv.setBackground(Ui.ripple(this, Ui.bg(0x33FFFFFF, 18, this), Theme.accentSoft()));
        iv.setClickable(true);
        iv.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                jdn += delta;
                build();
            }
        });
        return iv;
    }

    private void buildAllCalendars() {
        content.addView(Ui.sectionTitle(this, "همه‌ی تقویم‌ها"));
        LinearLayout card = Ui.card(this);
        for (int sys : Cal.PRIMARY) {
            LinearLayout r = Ui.row(this);
            Ui.pad(r, 2, 9, 2, 9);
            View dot = new View(this);
            dot.setBackground(Ui.circle(Theme.accent()));
            LinearLayout.LayoutParams dlp = Ui.lp(Ui.dp(this, 8), Ui.dp(this, 8));
            dlp.rightMargin = Ui.dp(this, 10);
            r.addView(dot, dlp);
            r.addView(Ui.text(this, Cal.sysName(sys), 14, Theme.text()));
            r.addView(Ui.spacer(this, 1));
            int[] v = Cal.fromJdn(sys, jdn);
            r.addView(Ui.text(this, Cal.format(sys, jdn), 14, Theme.accent()));
            card.addView(r);
        }
        content.addView(card);
    }

    private void buildEvents() {
        content.addView(Ui.sectionTitle(this, "رویدادها و مناسبت‌ها"));
        LinearLayout card = Ui.card(this);

        List<String> hol = Holidays.forJdn(jdn);
        if (Cal.week(jdn) == 6) {
            card.addView(holidayRow("جمعه — تعطیل هفتگی"));
        }
        for (String h : hol) card.addView(holidayRow(h));

        List<Event> ev = Store.forJdn(jdn);
        for (final Event e : ev) {
            LinearLayout r = Ui.row(this);
            Ui.pad(r, 2, 9, 2, 9);
            r.addView(Ui.text(this, e.allDay() ? "تمام روز" : Fmt.clock(e.minutes), 13, Theme.accent()));
            LinearLayout col = Ui.col(this);
            LinearLayout.LayoutParams clp = Ui.lp(0, ViewGroup.LayoutParams.WRAP_CONTENT);
            clp.weight = 1;
            clp.leftMargin = Ui.dp(this, 12);
            col.addView(Ui.text(this, e.title, 15, Theme.text()));
            if (!e.note.isEmpty()) col.addView(Ui.text(this, e.note, 12, Theme.sub()));
            r.addView(col, clp);
            r.setClickable(true);
            r.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    EventDialog.show(DayActivity.this, jdn, e, new Runnable() {
                        public void run() { build(); Reminder.apply(DayActivity.this); }
                    });
                }
            });
            card.addView(r);
        }

        if (hol.isEmpty() && ev.isEmpty() && Cal.week(jdn) != 6) {
            card.addView(Ui.text(this, "مناسبت یا رویدادی ثبت نشده است.", 13, Theme.sub()));
        }

        TextView add = Ui.text(this, "＋  افزودن رویداد", 14, Theme.accent());
        Ui.pad(add, 2, 12, 2, 2);
        add.setClickable(true);
        add.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                EventDialog.show(DayActivity.this, jdn, null, new Runnable() {
                    public void run() { build(); Reminder.apply(DayActivity.this); }
                });
            }
        });
        card.addView(Ui.divider(this, 0.6f));
        card.addView(add);
        content.addView(card);
    }

    private View holidayRow(String text) {
        LinearLayout r = Ui.row(this);
        Ui.pad(r, 2, 9, 2, 9);
        r.addView(Ui.icon(this, R.drawable.ic_flag, 16, Theme.holiday()));
        TextView t = Ui.text(this, text, 14, Theme.holiday());
        LinearLayout.LayoutParams tlp = Ui.lp(0, ViewGroup.LayoutParams.WRAP_CONTENT);
        tlp.weight = 1;
        tlp.leftMargin = Ui.dp(this, 10);
        r.addView(t, tlp);
        return r;
    }

    private void buildActions() {
        LinearLayout row = Ui.row(this);
        row.addView(actionCard(R.drawable.ic_share, "اشتراک", new Runnable() {
            public void run() { share(); }
        }));
        row.addView(actionCard(R.drawable.ic_globe, "اعصار", new Runnable() {
            public void run() {
                startActivity(new Intent(DayActivity.this, ErasActivity.class).putExtra("jdn", jdn));
            }
        }));
        row.addView(actionCard(R.drawable.ic_list, "همه رویدادها", new Runnable() {
            public void run() { startActivity(new Intent(DayActivity.this, EventsActivity.class)); }
        }));
        LinearLayout.LayoutParams lp = Ui.lp(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = Ui.dp(this, 4);
        content.addView(row, lp);
    }

    private View actionCard(int icon, String label, final Runnable onClick) {
        LinearLayout l = Ui.col(this);
        l.setGravity(Gravity.CENTER);
        l.setBackground(Ui.ripple(this, Ui.bg(Theme.card(), 20, this), Theme.accentSoft()));
        Ui.pad(l, 10, 16, 10, 16);
        LinearLayout.LayoutParams lp = Ui.lp(0, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.weight = 1;
        lp.rightMargin = Ui.dp(this, 10);
        l.setLayoutParams(lp);
        l.addView(Ui.icon(this, icon, 24, Theme.accent()));
        TextView t = Ui.text(this, label, 12, Theme.text());
        LinearLayout.LayoutParams tlp = Ui.lp(ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        tlp.topMargin = Ui.dp(this, 8);
        l.addView(t, tlp);
        l.setClickable(true);
        l.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { onClick.run(); }
        });
        return l;
    }

    private void share() {
        StringBuilder sb = new StringBuilder();
        sb.append("📅 ").append(Cal.format(Cal.JALALI, jdn)).append(" (").append(Cal.WEEK[Cal.week(jdn)]).append(")\n");
        for (int sys : Cal.PRIMARY) {
            sb.append("• ").append(Cal.sysName(sys)).append(": ").append(Cal.format(sys, jdn)).append("\n");
        }
        for (String h : Holidays.forJdn(jdn)) sb.append("🎌 ").append(h).append("\n");
        for (Event e : Store.forJdn(jdn)) {
            sb.append("🔔 ").append(e.allDay() ? "" : Fmt.clock(e.minutes) + " ").append(e.title).append("\n");
        }
        sb.append("— تقویم پرو");
        Intent i = new Intent(Intent.ACTION_SEND);
        i.setType("text/plain");
        i.putExtra(Intent.EXTRA_TEXT, sb.toString());
        startActivity(Intent.createChooser(i, "اشتراک‌گذاری"));
    }
}
