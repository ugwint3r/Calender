package com.calendarpro.app.ui;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.text.InputType;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.calendarpro.app.data.Cal;
import com.calendarpro.app.data.Cfg;
import com.calendarpro.app.data.Event;
import com.calendarpro.app.data.Store;
import com.calendarpro.app.util.Fmt;
import com.calendarpro.app.util.Theme;

public final class EventDialog {
    private EventDialog() {}

    public static void show(final Activity a, final long jdn, final Event existing, final Runnable onDone) {
        final LinearLayout root = Ui.col(a);
        int p = Ui.dp(a, 20);
        root.setPadding(p, Ui.dp(a, 8), p, p);

        TextView head = Ui.text(a,
                Cal.format(Cal.JALALI, jdn) + "  •  " + Cal.WEEK[Cal.week(jdn)],
                13, Theme.sub());
        root.addView(head);
        root.addView(Ui.gap(a, 8));

        final EditText title = input(a, "عنوان رویداد");
        if (existing != null) title.setText(existing.title);
        root.addView(title);
        root.addView(Ui.gap(a, 6));

        final EditText time = input(a, "ساعت ۱۴:۳۰  (خالی = تمام روز)");
        time.setInputType(InputType.TYPE_CLASS_DATETIME);
        if (existing != null && !existing.allDay()) time.setText(Fmt.clock(existing.minutes));
        root.addView(time);
        root.addView(Ui.gap(a, 6));

        final EditText note = input(a, "یادداشت (اختیاری)");
        if (existing != null) note.setText(existing.note);
        root.addView(note);

        AlertDialog.Builder b = new AlertDialog.Builder(a);
        b.setTitle(existing == null ? "افزودن رویداد" : "ویرایش رویداد");
        b.setView(root);
        b.setPositiveButton("ذخیره", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface d, int w) {
                String t = title.getText().toString().trim();
                if (t.isEmpty()) t = "رویداد";
                int minutes = parseMinutes(time.getText().toString());
                if (existing == null) {
                    Store.add(new Event(jdn, minutes, Cfg.accent(), t, note.getText().toString()));
                } else {
                    existing.jdn = jdn;
                    existing.minutes = minutes;
                    existing.title = t;
                    existing.note = note.getText().toString();
                    Store.update(existing);
                }
                if (onDone != null) onDone.run();
            }
        });
        b.setNegativeButton("انصراف", null);
        if (existing != null) {
            b.setNeutralButton("حذف", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface d, int w) {
                    Store.delete(existing.id);
                    if (onDone != null) onDone.run();
                }
            });
        }
        b.show();
    }

    private static EditText input(Activity a, String hint) {
        EditText e = new EditText(a);
        e.setHint(hint);
        e.setHintTextColor(Theme.sub());
        e.setTextColor(Theme.text());
        e.setSingleLine(true);
        return e;
    }

    /** Accepts Persian or Latin digits, "14:30" or "14". Returns minutes or -1. */
    public static int parseMinutes(String raw) {
        if (raw == null) return -1;
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < raw.length(); i++) {
            char c = raw.charAt(i);
            if (c >= '۰' && c <= '۹') c = (char) ('0' + (c - '۰'));
            else if (c >= '٠' && c <= '٩') c = (char) ('0' + (c - '٠'));
            sb.append(c);
        }
        String s = sb.toString().trim();
        if (s.isEmpty()) return -1;
        s = s.replace('：', ':').replace('.', ':');
        try {
            if (s.contains(":")) {
                String[] p = s.split(":");
                int h = Integer.parseInt(p[0].trim());
                int m = p.length > 1 && !p[1].trim().isEmpty() ? Integer.parseInt(p[1].trim()) : 0;
                if (h < 0 || h > 23 || m < 0 || m > 59) return -1;
                return h * 60 + m;
            }
            int h = Integer.parseInt(s);
            if (h < 0 || h > 23) return -1;
            return h * 60;
        } catch (Exception e) {
            return -1;
        }
    }
}
