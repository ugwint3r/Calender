package com.calendarpro.app.ui;

import android.app.Activity;
import android.content.Intent;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import com.calendarpro.app.R;
import com.calendarpro.app.data.Cal;
import com.calendarpro.app.util.Fmt;
import com.calendarpro.app.util.Theme;

import java.util.List;

/** "همه‌ی اعصار" — today's date across many world eras and calendar systems. */
public class ErasActivity extends Activity {

    private long jdn;
    private long today;
    private LinearLayout content;

    private static final int[] ERA_COLORS = {
            0xFF5B8DEF, 0xFF2DD4BF, 0xFFA855F7, 0xFFFB923C, 0xFFEC4899, 0xFF34D399,
            0xFFE8BE6A, 0xFFFB7185, 0xFF60A5FA, 0xFFF472B6, 0xFF4ADE80, 0xFFFACC15,
            0xFFC084FC, 0xFF22D3EE, 0xFFFF8A65};

    @Override
    protected void onCreate(Bundle b) {
        Theme.apply(this);
        super.onCreate(b);
        today = Cal.todayJdn();
        jdn = getIntent().getLongExtra("jdn", today);

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Theme.bg());
        root.addView(new GlowView(this), new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        ScrollView scroll = new ScrollView(this);
        scroll.setVerticalScrollBarEnabled(false);
        content = Ui.col(this);
        Ui.pad(content, 14, 6, 14, 40);
        scroll.addView(content);
        root.addView(scroll, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        setContentView(root);
        build();
    }

    private void build() {
        content.removeAllViews();
        buildTop();
        buildHero();
        buildEras();
        buildFooter();
    }

    private void buildTop() {
        LinearLayout top = Ui.row(this);
        ImageView back = Ui.icon(this, R.drawable.ic_back, 40, Theme.text());
        back.setPadding(Ui.dp(this, 8), Ui.dp(this, 8), Ui.dp(this, 8), Ui.dp(this, 8));
        back.setClickable(true);
        back.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { finish(); }
        });
        top.addView(back);
        LinearLayout titles = Ui.col(this);
        titles.addView(Ui.bold(Ui.text(this, "همه‌ی اعصار", 18, Theme.text())));
        titles.addView(Ui.text(this, "گاه‌شماری‌های جهان و دوران‌های کهن", 11, Theme.sub()));
        LinearLayout.LayoutParams tlp = Ui.lp(0, ViewGroup.LayoutParams.WRAP_CONTENT);
        tlp.weight = 1;
        tlp.leftMargin = Ui.dp(this, 4);
        top.addView(titles, tlp);
        LinearLayout.LayoutParams lp = Ui.lp(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.bottomMargin = Ui.dp(this, 10);
        content.addView(top, lp);
    }

    private void buildHero() {
        LinearLayout hero = Ui.col(this);
        int a = Theme.accent();
        hero.setBackground(Ui.gradient(GradientDrawable.Orientation.TL_BR, new int[]{
                Ui.withAlpha(a, 0xFF), Ui.darken(a, 0.5f)}, 24, this));
        int p = Ui.dp(this, 18);
        hero.setPadding(p, p, p, p);

        LinearLayout nav = Ui.row(this);
        nav.addView(arrow(R.drawable.ic_back, -1));
        nav.addView(Ui.spacer(this, 1));
        TextView badge = Ui.text(this, Fmt.rel(today, jdn), 13, 0xFF1A1206);
        Ui.pad(badge, 12, 6, 12, 6);
        badge.setBackground(Ui.bg(0x55FFFFFF, 14, this));
        nav.addView(badge);
        nav.addView(Ui.spacer(this, 1));
        nav.addView(arrow(R.drawable.ic_chev_right, 1));
        hero.addView(nav);

        TextView main = Ui.bold(Ui.text(this, Cal.format(Cal.GREGORIAN, jdn), 24, 0xFFFFFFFF));
        main.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams mlp = Ui.lp(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        mlp.topMargin = Ui.dp(this, 12);
        hero.addView(main, mlp);
        TextView sub = Ui.text(this, Cal.WEEK[Cal.week(jdn)] + "  •  " + Cal.format(Cal.JALALI, jdn),
                13, 0xE6FFFFFF);
        sub.setGravity(Gravity.CENTER);
        hero.addView(sub);
        content.addView(hero, Ui.cardLp(this));
    }

    private ImageView arrow(int res, final int delta) {
        ImageView iv = Ui.icon(this, res, 28, 0xFFFFFFFF);
        iv.setPadding(Ui.dp(this, 6), Ui.dp(this, 6), Ui.dp(this, 6), Ui.dp(this, 6));
        iv.setBackground(Ui.ripple(this, Ui.bg(0x33FFFFFF, 18, this), Theme.accentSoft()));
        iv.setClickable(true);
        iv.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { jdn += delta; build(); }
        });
        return iv;
    }

    private void buildEras() {
        List<String[]> eras = Cal.eras(jdn);
        for (int i = 0; i < eras.size(); i++) {
            String[] e = eras.get(i);
            int color = ERA_COLORS[i % ERA_COLORS.length];
            content.addView(eraCard(e[0], e[1], color));
        }
    }

    private View eraCard(String name, String value, int color) {
        LinearLayout card = Ui.row(this);
        card.setBackground(Ui.bg(Theme.card(), 18, this));
        int p = Ui.dp(this, 14);
        card.setPadding(p, p, p, p);
        LinearLayout.LayoutParams lp = Ui.lp(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.bottomMargin = Ui.dp(this, 10);
        card.setLayoutParams(lp);

        TextView badge = Ui.text(this, name.substring(0, 1), 18, 0xFFFFFFFF);
        badge.setGravity(Gravity.CENTER);
        badge.setBackground(Ui.gradient(color, Ui.darken(color, 0.25f), 14, this));
        int bs = Ui.dp(this, 44);
        card.addView(badge, Ui.lp(bs, bs));

        LinearLayout col = Ui.col(this);
        LinearLayout.LayoutParams clp = Ui.lp(0, ViewGroup.LayoutParams.WRAP_CONTENT);
        clp.weight = 1;
        clp.leftMargin = Ui.dp(this, 14);
        col.addView(Ui.text(this, name, 13, Theme.sub()));
        TextView v = Ui.bold(Ui.text(this, value, 18, Theme.text()));
        col.addView(v);
        card.addView(col, clp);
        return card;
    }

    private void buildFooter() {
        TextView t = Ui.text(this, "شمارهٔ روز ژولیوسی پایه‌ی همه‌ی تبدیل‌هاست • تقویم پرو", 11, Theme.sub());
        t.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams lp = Ui.lp(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = Ui.dp(this, 10);
        content.addView(t, lp);
    }
}
