package com.calendarpro.app.ui;

import android.app.Activity;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import com.calendarpro.app.App;
import com.calendarpro.app.R;
import com.calendarpro.app.data.Cal;
import com.calendarpro.app.data.Cfg;
import com.calendarpro.app.data.Event;
import com.calendarpro.app.data.Holidays;
import com.calendarpro.app.data.Reminder;
import com.calendarpro.app.data.Store;
import com.calendarpro.app.util.Fmt;
import com.calendarpro.app.util.Theme;

import java.util.List;

public class MainActivity extends Activity {

    private ScrollView scroll;
    private LinearLayout content;
    private int primary;
    private int cy, cm;
    private long selJdn;
    private long today;

    @Override
    protected void onCreate(android.os.Bundle b) {
        Theme.apply(this);
        super.onCreate(b);
        today = Cal.todayJdn();
        primary = Cfg.primaryCal();
        int[] t = Cal.fromJdn(primary, today);
        cy = t[0];
        cm = t[1];
        selJdn = today;

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Theme.bg());
        root.addView(new GlowView(this), new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        scroll = new ScrollView(this);
        scroll.setVerticalScrollBarEnabled(false);
        scroll.setFillViewport(true);
        content = Ui.col(this);
        Ui.pad(content, 14, 6, 14, 40);
        scroll.addView(content);
        root.addView(scroll, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        setContentView(root);
        build();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (App.appliedTheme != Cfg.theme() || App.appliedAccent != Cfg.accent()
                || App.appliedDigits != Cfg.digits()) {
            recreate();
            return;
        }
        if (Cfg.primaryCal() != primary) {
            primary = Cfg.primaryCal();
            int[] t = Cal.fromJdn(primary, today);
            cy = t[0];
            cm = t[1];
        }
        build();
    }

    private void build() {
        int y = scroll.getScrollY();
        content.removeAllViews();
        buildTop();
        buildMonthHeader();
        buildCalChips();
        buildGrid();
        buildDaySummary();
        buildUpcoming();
        buildActions();
        buildFooter();
        scroll.post(new Runnable() {
            public void run() { scroll.scrollTo(0, 0); }
        });
    }

    // ------------------------------------------------------------ top bar

    private void buildTop() {
        LinearLayout top = Ui.row(this);
        LinearLayout titles = Ui.col(this);
        TextView t = Ui.bold(Ui.text(this, "تقویم پرو", 22, Theme.accent()));
        titles.addView(t);
        titles.addView(Ui.text(this,
                Cal.WEEK[Cal.week(today)] + " • " + Cal.format(Cal.JALALI, today),
                12, Theme.sub()));
        top.addView(titles);
        top.addView(Ui.spacer(this, 1));
        top.addView(iconButton(R.drawable.ic_globe, new Runnable() {
            public void run() {
                startActivity(new Intent(MainActivity.this, ErasActivity.class)
                        .putExtra("jdn", selJdn));
            }
        }));
        top.addView(iconButton(R.drawable.ic_list, new Runnable() {
            public void run() { startActivity(new Intent(MainActivity.this, EventsActivity.class)); }
        }));
        top.addView(iconButton(R.drawable.ic_settings, new Runnable() {
            public void run() { startActivity(new Intent(MainActivity.this, SettingsActivity.class)); }
        }));
        LinearLayout.LayoutParams lp = Ui.lp(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.bottomMargin = Ui.dp(this, 10);
        content.addView(top, lp);
    }

    private ImageView iconButton(int res, final Runnable onClick) {
        ImageView iv = Ui.icon(this, res, 42, Theme.text());
        iv.setPadding(Ui.dp(this, 10), Ui.dp(this, 10), Ui.dp(this, 10), Ui.dp(this, 10));
        iv.setBackground(Ui.ripple(this, Ui.bg(0x00000000, 22, this), Theme.accentSoft()));
        iv.setClickable(true);
        iv.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { onClick.run(); }
        });
        return iv;
    }

    // ------------------------------------------------------------ month header

    private void buildMonthHeader() {
        LinearLayout card = Ui.col(this);
        card.setBackground(Ui.gradient(Theme.dark ? Ui.withAlpha(Theme.accent(), 0x4A)
                : Ui.withAlpha(Theme.accent(), 0x33),
                Theme.dark ? 0x00000000 : Ui.withAlpha(Theme.accent(), 0x0A), 22, this));
        int p = Ui.dp(this, 14);
        card.setPadding(p, p, p, p);

        LinearLayout row = Ui.row(this);
        row.addView(navButton(R.drawable.ic_back, new Runnable() {
            public void run() { shift(-1); }
        }));
        LinearLayout mid = Ui.col(this);
        mid.setGravity(Gravity.CENTER);
        TextView title = Ui.bold(Ui.text(this, Cal.monthTitle(primary, cy, cm), 22, Theme.text()));
        mid.addView(title);
        TextView sub = Ui.text(this, Cal.sysName(primary), 12, Theme.sub());
        mid.addView(sub);
        LinearLayout.LayoutParams mlp = Ui.lp(0, ViewGroup.LayoutParams.WRAP_CONTENT);
        mlp.weight = 1;
        row.addView(mid, mlp);
        row.addView(navButton(R.drawable.ic_chev_right, new Runnable() {
            public void run() { shift(1); }
        }));
        card.addView(row);

        LinearLayout tools = Ui.row(this);
        LinearLayout.LayoutParams tlp = Ui.lp(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        tlp.topMargin = Ui.dp(this, 10);
        tools.addView(pill("امروز", new Runnable() {
            public void run() { goToday(); }
        }));
        tools.addView(Ui.spacer(this, 1));
        TextView range = Ui.text(this, monthRange(), 12, Theme.sub());
        tools.addView(range);
        card.addView(tools, tlp);

        content.addView(card, Ui.cardLp(this));
    }

    private String monthRange() {
        int days = Cal.daysInMonth(primary, cy, cm);
        long a = Cal.toJdn(primary, cy, cm, 1);
        long b = Cal.toJdn(primary, cy, cm, days);
        int other = (primary == Cal.GREGORIAN) ? Cal.JALALI : Cal.GREGORIAN;
        return Cal.formatShort(other, a) + " تا " + Cal.formatShort(other, b) + " " + Cal.sysShort(other);
    }

    private ImageView navButton(int res, final Runnable onClick) {
        ImageView iv = Ui.icon(this, res, 34, Theme.text());
        iv.setPadding(Ui.dp(this, 6), Ui.dp(this, 6), Ui.dp(this, 6), Ui.dp(this, 6));
        iv.setBackground(Ui.ripple(this, Ui.bg(Theme.dark ? 0x22FFFFFF : 0x11000000, 20, this),
                Theme.accentSoft()));
        iv.setClickable(true);
        iv.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { onClick.run(); }
        });
        return iv;
    }

    private TextView pill(String label, final Runnable onClick) {
        TextView t = Ui.text(this, label, 13, 0xFF1A1206);
        Ui.pad(t, 16, 8, 16, 8);
        t.setBackground(Ui.ripple(this, Ui.bg(Theme.accent(), 16, this), Theme.accentSoft()));
        t.setClickable(true);
        t.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { onClick.run(); }
        });
        return t;
    }

    // ------------------------------------------------------------ calendar chips

    private void buildCalChips() {
        HorizontalScrollView hsv = new HorizontalScrollView(this);
        hsv.setHorizontalScrollBarEnabled(false);
        LinearLayout row = Ui.row(this);
        for (final int sys : Cal.PRIMARY) {
            LinearLayout chip = Ui.chip(this, Cal.sysShort(sys), sys == primary);
            LinearLayout.LayoutParams lp = Ui.lp(ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT);
            lp.rightMargin = Ui.dp(this, 8);
            chip.setLayoutParams(lp);
            chip.setClickable(true);
            chip.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    primary = sys;
                    Cfg.primaryCal(sys);
                    int[] t = Cal.fromJdn(primary, today);
                    cy = t[0];
                    cm = t[1];
                    build();
                }
            });
            row.addView(chip);
        }
        hsv.addView(row);
        LinearLayout.LayoutParams lp = Ui.lp(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.bottomMargin = Ui.dp(this, 10);
        content.addView(hsv, lp);
    }

    // ------------------------------------------------------------ grid

    private void buildWeekHeader() {
        LinearLayout row = Ui.row(this);
        int ws = Cfg.weekStart();
        for (int i = 0; i < 7; i++) {
            int idx = (ws + i) % 7;
            TextView t = Ui.text(this, Cal.WEEK_SHORT[idx], 12,
                    idx == 6 ? Theme.holiday() : Theme.sub());
            t.setGravity(Gravity.CENTER);
            LinearLayout.LayoutParams lp = Ui.lp(0, ViewGroup.LayoutParams.WRAP_CONTENT);
            lp.weight = 1;
            t.setLayoutParams(lp);
            row.addView(t);
        }
        LinearLayout.LayoutParams lp = Ui.lp(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.bottomMargin = Ui.dp(this, 6);
        content.addView(row, lp);
    }

    private void buildGrid() {
        buildWeekHeader();
        LinearLayout card = Ui.col(this);
        card.setBackground(Ui.bg(Theme.dark ? 0x14FFFFFF : 0x08FFFFFF, 20, this));
        int pad = Ui.dp(this, 6);
        card.setPadding(pad, pad, pad, pad);

        long firstJdn = Cal.toJdn(primary, cy, cm, 1);
        int days = Cal.daysInMonth(primary, cy, cm);
        int ws = Cfg.weekStart();
        int lead = (Cal.week(firstJdn) - ws + 7) % 7;
        int total = lead + days;
        int rows = (total + 6) / 7;
        if (rows < 5) rows = 5;

        for (int r = 0; r < rows; r++) {
            LinearLayout weekRow = Ui.row(this);
            for (int col = 0; col < 7; col++) {
                int k = r * 7 + col;
                long jdn = firstJdn - lead + k;
                boolean other = (k < lead) || (k >= lead + days);
                weekRow.addView(dayCell(jdn, other));
            }
            card.addView(weekRow);
        }
        content.addView(card, Ui.cardLp(this));
    }

    private int[] secondarySystems() {
        int[] order = {Cal.JALALI, Cal.GREGORIAN, Cal.HIJRI};
        int[] out = new int[2];
        int n = 0;
        for (int sys : order) {
            if (sys == primary) continue;
            if (n < 2) out[n++] = sys;
        }
        if (n < 2) {
            int[] extra = {Cal.JULIAN, Cal.HEBREW};
            for (int sys : extra) {
                if (n >= 2) break;
                if (sys == primary) continue;
                out[n++] = sys;
            }
        }
        return out;
    }

    private View dayCell(final long jdn, boolean other) {
        LinearLayout cell = Ui.col(this);
        cell.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, Ui.dp(this, 56), 1);
        cell.setLayoutParams(lp);

        boolean isToday = jdn == today;
        boolean selected = jdn == selJdn;
        boolean holiday = Holidays.red(jdn);
        boolean hasEvent = Store.countForJdn(jdn) > 0;

        int[] pa = Cal.fromJdn(primary, jdn);

        TextView num = Ui.text(this, Fmt.num(pa[2]), 16, 0xFFFFFFFF);
        Ui.bold(num);
        num.setGravity(Gravity.CENTER);
        int sq = Ui.dp(this, 32);
        LinearLayout.LayoutParams nlp = new LinearLayout.LayoutParams(sq, sq);
        num.setLayoutParams(nlp);

        if (selected) {
            num.setBackground(Ui.circle(Theme.accent()));
            num.setTextColor(0xFF1A1206);
        } else if (isToday) {
            num.setBackground(Ui.ring(0x00000000, Theme.accent(), 1.6f, this));
            num.setTextColor(Theme.accent());
        } else if (other) {
            num.setTextColor(Ui.withAlpha(Theme.sub(), 0x99));
        } else {
            num.setTextColor(holiday ? Theme.holiday() : Theme.text());
        }
        cell.addView(num);

        if (Cfg.secondary()) {
            int[] sys = secondarySystems();
            StringBuilder sb = new StringBuilder();
            for (int s : sys) {
                if (sb.length() > 0) sb.append(" ");
                sb.append(Fmt.num(Cal.fromJdn(s, jdn)[2]));
            }
            TextView sec = Ui.text(this, sb.toString(), 9,
                    other ? Ui.withAlpha(Theme.sub(), 0x77) : Theme.sub());
            sec.setGravity(Gravity.CENTER);
            LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            slp.topMargin = Ui.dp(this, 1);
            cell.addView(sec, slp);
        }

        View dot = new View(this);
        dot.setBackground(Ui.circle(hasEvent ? Theme.accent() : 0x00000000));
        LinearLayout.LayoutParams dlp = Ui.lp(Ui.dp(this, 4), Ui.dp(this, 4));
        dlp.topMargin = Ui.dp(this, 2);
        cell.addView(dot, dlp);

        if (other) cell.setAlpha(0.6f);

        cell.setBackground(Ui.ripple(this, Ui.bg(0x00000000, 16, this), Theme.accentSoft()));
        cell.setClickable(true);
        final long jd = jdn;
        cell.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                selJdn = jd;
                build();
            }
        });
        cell.setOnLongClickListener(new View.OnLongClickListener() {
            public boolean onLongClick(View v) {
                selJdn = jd;
                EventDialog.show(MainActivity.this, jd, null, new Runnable() {
                    public void run() { build(); Reminder.apply(MainActivity.this); }
                });
                return true;
            }
        });
        return cell;
    }

    // ------------------------------------------------------------ day summary

    private void buildDaySummary() {
        LinearLayout card = Ui.card(this);
        LinearLayout head = Ui.row(this);
        LinearLayout left = Ui.col(this);
        TextView d = Ui.bold(Ui.text(this, Cal.format(primary, selJdn), 19, Theme.text()));
        left.addView(d);
        left.addView(Ui.text(this, Cal.WEEK[Cal.week(selJdn)] + " • " +
                Fmt.rel(today, selJdn), 12, Theme.sub()));
        head.addView(left);
        head.addView(Ui.spacer(this, 1));
        ImageView go = Ui.icon(this, R.drawable.ic_chev_right, 24, Theme.accent());
        head.addView(go);
        head.setClickable(true);
        head.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, DayActivity.class)
                        .putExtra("jdn", selJdn));
            }
        });
        card.addView(head);

        card.addView(Ui.divider(this, 0.6f));
        int[] show = {Cal.JALALI, Cal.GREGORIAN, Cal.HIJRI, Cal.HEBREW, Cal.COPTIC, Cal.JULIAN};
        for (int sys : show) {
            card.addView(infoRow(Cal.sysName(sys), Cal.format(sys, selJdn)));
        }

        List<String> hol = Holidays.forJdn(selJdn);
        for (String h : hol) {
            card.addView(infoRow("تعطیل رسمی", h, Theme.holiday()));
        }
        if (Cal.week(selJdn) == 6) {
            card.addView(infoRow("پایان هفته", "جمعه", Theme.holiday()));
        }

        List<Event> ev = Store.forJdn(selJdn);
        if (!ev.isEmpty()) {
            card.addView(Ui.divider(this, 0.6f));
            for (final Event e : ev) {
                card.addView(eventRow(e));
            }
        }

        TextView add = Ui.text(this, "＋  افزودن رویداد", 14, Theme.accent());
        Ui.pad(add, 0, 12, 0, 2);
        add.setClickable(true);
        add.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                EventDialog.show(MainActivity.this, selJdn, null, new Runnable() {
                    public void run() { build(); Reminder.apply(MainActivity.this); }
                });
            }
        });
        card.addView(Ui.divider(this, 0.6f));
        card.addView(add);

        content.addView(card);
    }

    private View infoRow(String label, String value) {
        LinearLayout r = Ui.row(this);
        Ui.pad(r, 2, 7, 2, 7);
        TextView l = Ui.text(this, label, 13, Theme.sub());
        r.addView(l);
        r.addView(Ui.spacer(this, 1));
        r.addView(Ui.text(this, value, 14, Theme.text()));
        return r;
    }

    private View infoRow(String label, String value, int color) {
        LinearLayout r = Ui.row(this);
        Ui.pad(r, 2, 7, 2, 7);
        r.addView(Ui.text(this, label, 13, Theme.sub()));
        r.addView(Ui.spacer(this, 1));
        r.addView(Ui.text(this, value, 14, color));
        return r;
    }

    private View eventRow(final Event e) {
        LinearLayout r = Ui.row(this);
        Ui.pad(r, 2, 9, 2, 9);
        View dot = new View(this);
        dot.setBackground(Ui.circle(Theme.accent()));
        LinearLayout.LayoutParams dlp = Ui.lp(Ui.dp(this, 8), Ui.dp(this, 8));
        dlp.rightMargin = Ui.dp(this, 10);
        r.addView(dot, dlp);
        LinearLayout col = Ui.col(this);
        col.addView(Ui.text(this, e.title, 15, Theme.text()));
        if (!e.note.isEmpty()) col.addView(Ui.text(this, e.note, 12, Theme.sub()));
        LinearLayout.LayoutParams clp = Ui.lp(0, ViewGroup.LayoutParams.WRAP_CONTENT);
        clp.weight = 1;
        r.addView(col, clp);
        if (!e.allDay()) r.addView(Ui.text(this, Fmt.clock(e.minutes), 13, Theme.accent()));
        r.setClickable(true);
        r.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                EventDialog.show(MainActivity.this, e.jdn, e, new Runnable() {
                    public void run() { build(); Reminder.apply(MainActivity.this); }
                });
            }
        });
        return r;
    }

    // ------------------------------------------------------------ upcoming

    private void buildUpcoming() {
        List<Event> up = Store.upcoming(today, 3);
        if (up.isEmpty()) return;
        content.addView(Ui.sectionTitle(this, "رویدادهای پیش‌رو"));
        LinearLayout card = Ui.card(this);
        for (Event e : up) {
            LinearLayout r = Ui.row(this);
            Ui.pad(r, 2, 8, 2, 8);
            LinearLayout col = Ui.col(this);
            col.addView(Ui.text(this, e.title, 14, Theme.text()));
            col.addView(Ui.text(this, Cal.format(Cal.JALALI, e.jdn), 12, Theme.sub()));
            LinearLayout.LayoutParams clp = Ui.lp(0, ViewGroup.LayoutParams.WRAP_CONTENT);
            clp.weight = 1;
            r.addView(col, clp);
            r.addView(Ui.text(this, Fmt.rel(today, e.jdn), 12, Theme.accent()));
            card.addView(r);
        }
        content.addView(card);
    }

    // ------------------------------------------------------------ actions & footer

    private void buildActions() {
        LinearLayout row = Ui.row(this);
        row.addView(actionCard(R.drawable.ic_eras, "همه‌ی اعصار", new Runnable() {
            public void run() {
                startActivity(new Intent(MainActivity.this, ErasActivity.class)
                        .putExtra("jdn", selJdn));
            }
        }));
        row.addView(actionCard(R.drawable.ic_share, "اشتراک روز", new Runnable() {
            public void run() { shareDay(); }
        }));
        row.addView(actionCard(R.drawable.ic_palette, "ظاهر", new Runnable() {
            public void run() { startActivity(new Intent(MainActivity.this, SettingsActivity.class)); }
        }));
        LinearLayout.LayoutParams lp = Ui.lp(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = Ui.dp(this, 4);
        content.addView(row, lp);
    }

    private View actionCard(int icon, String label, final Runnable onClick) {
        LinearLayout l = Ui.col(this);
        l.setGravity(Gravity.CENTER);
        l.setBackground(Ui.ripple(this, Ui.bg(Theme.card(), 20, this), Theme.accentSoft()));
        Ui.pad(l, 10, 16, 10, 16);
        LinearLayout.LayoutParams lp = Ui.lp(0, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.weight = 1;
        lp.rightMargin = Ui.dp(this, 10);
        l.setLayoutParams(lp);
        l.addView(Ui.icon(this, icon, 24, Theme.accent()));
        TextView t = Ui.text(this, label, 12, Theme.text());
        LinearLayout.LayoutParams tlp = Ui.lp(ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        tlp.topMargin = Ui.dp(this, 8);
        l.addView(t, tlp);
        l.setClickable(true);
        l.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { onClick.run(); }
        });
        return l;
    }

    private void buildFooter() {
        TextView t = Ui.text(this, "تقویم پرو • همه‌ی اعصار", 11, Theme.sub());
        t.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams lp = Ui.lp(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = Ui.dp(this, 18);
        content.addView(t, lp);
    }

    // ------------------------------------------------------------ nav actions

    private void shift(int delta) {
        cm += delta;
        while (cm < 1) {
            cm += Cal.monthsInYear(primary, cy - 1);
            cy -= 1;
        }
        while (cm > Cal.monthsInYear(primary, cy)) {
            cm -= Cal.monthsInYear(primary, cy);
            cy += 1;
        }
        build();
    }

    private void goToday() {
        int[] t = Cal.fromJdn(primary, today);
        cy = t[0];
        cm = t[1];
        selJdn = today;
        build();
    }

    private void shareDay() {
        StringBuilder sb = new StringBuilder();
        sb.append("📅 ").append(Cal.format(Cal.JALALI, selJdn));
        sb.append(" (").append(Cal.WEEK[Cal.week(selJdn)]).append(")\n");
        for (int sys : Cal.PRIMARY) {
            sb.append("• ").append(Cal.sysName(sys)).append(": ")
                    .append(Cal.format(sys, selJdn)).append("\n");
        }
        List<String> hol = Holidays.forJdn(selJdn);
        for (String h : hol) sb.append("🎌 ").append(h).append("\n");
        List<Event> ev = Store.forJdn(selJdn);
        for (Event e : ev) {
            sb.append("🔔 ").append(e.allDay() ? "" : Fmt.clock(e.minutes) + " ")
                    .append(e.title).append("\n");
        }
        sb.append("— تقویم پرو");
        Intent i = new Intent(Intent.ACTION_SEND);
        i.setType("text/plain");
        i.putExtra(Intent.EXTRA_TEXT, sb.toString());
        startActivity(Intent.createChooser(i, "اشتراک‌گذاری روز"));
    }
}
