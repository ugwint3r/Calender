package com.calendarpro.app.util;

import com.calendarpro.app.data.Cfg;

public final class Fmt {
    private Fmt() {}

    private static final char[] FA = {'۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'};

    /** Always Persian digits. */
    public static String fa(String s) {
        if (s == null) return "";
        StringBuilder sb = new StringBuilder(s.length());
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c >= '0' && c <= '9') sb.append(FA[c - '0']);
            else sb.append(c);
        }
        return sb.toString();
    }

    public static String fa(int n) { return fa(Integer.toString(n)); }

    public static String fa(long n) { return fa(Long.toString(n)); }

    /** Digits obey the user's setting (Persian or Latin). */
    public static String num(String s) {
        if (s == null) return "";
        if (Cfg.digits() == 1) return s;
        return fa(s);
    }

    public static String num(int n) { return num(Integer.toString(n)); }

    public static String two(int v) { return (v < 10 ? "0" : "") + v; }

    public static String clock(int hour, int minute) { return num(two(hour) + ":" + two(minute)); }

    public static String clock(int totalMinutes) {
        int h = (totalMinutes / 60) % 24, m = totalMinutes % 60;
        return clock(h, m);
    }

    /** Human friendly distance between two JDNs, in Persian. */
    public static String rel(long from, long to) {
        long diff = to - from;
        if (diff == 0) return "امروز";
        String s = diff > 0 ? "بعد" : "قبل";
        long d = Math.abs(diff);
        if (d == 1) return (diff > 0 ? "فردا" : "دیروز");
        if (d < 30) return fa(d) + " روز " + s;
        if (d < 365) return fa(Math.round(d / 30.0)) + " ماه " + s;
        return fa(Math.round(d / 365.0)) + " سال " + s;
    }
}
