package com.calendarpro.app.util;

import android.app.Activity;
import android.content.res.Configuration;

import com.calendarpro.app.R;
import com.calendarpro.app.data.Cfg;

public final class Theme {
    private Theme() {}

    public static final int[] ACCENTS = {
            0xFFE8BE6A, 0xFFA855F7, 0xFF5B8DEF, 0xFF2DD4BF,
            0xFFEC4899, 0xFFFB7185, 0xFF34D399, 0xFFFB923C};
    public static final String[] ACCENT_NAMES = {
            "طلایی", "آمیتیست", "نیلی", "فیروزه‌ای", "رُز", "مرجانی", "زمردی", "کهربایی"};

    public static boolean dark = true;

    public static int accent() {
        int i = Cfg.accent();
        if (i < 0 || i >= ACCENTS.length) i = 0;
        return ACCENTS[i];
    }

    public static int bg() { return dark ? 0xFF07050F : 0xFFF7F5FC; }
    public static int bg2() { return dark ? 0xFF0C0918 : 0xFFEFEBF9; }
    public static int card() { return dark ? 0xFF140F26 : 0xFFFFFFFF; }
    public static int card2() { return dark ? 0xFF1C1533 : 0xFFEDE7F8; }
    public static int text() { return dark ? 0xFFF4F1FB : 0xFF16121F; }
    public static int sub() { return dark ? 0xFFA69FBD : 0xFF6B6480; }
    public static int line() { return dark ? 0x1FF4F1FB : 0x14000000; }
    public static int holiday() { return dark ? 0xFFFF8A80 : 0xFFD32F2F; }
    public static int accentSoft() { return (accent() & 0x00FFFFFF) | 0x2E000000; }
    public static int accentPale() { return (accent() & 0x00FFFFFF) | 0x16000000; }
    public static int scrim() { return dark ? 0xCC07050F : 0xCCF7F5FC; }

    public static int gradientTop() { return dark ? 0xFF1A1140 : 0xFFFBF9FF; }
    public static int gradientMid() { return dark ? 0xFF0C0918 : 0xFFF3EEFC; }
    public static int gradientBottom() { return dark ? 0xFF07050F : 0xFFF7F5FC; }

    public static void apply(Activity a) {
        int mode = Cfg.theme();
        boolean night;
        int ui = a.getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK;
        night = ui == Configuration.UI_MODE_NIGHT_YES;
        if (mode == 0) dark = true;
        else if (mode == 1) dark = false;
        else dark = night;
        com.calendarpro.app.App.appliedTheme = Cfg.theme();
        com.calendarpro.app.App.appliedAccent = Cfg.accent();
        com.calendarpro.app.App.appliedDigits = Cfg.digits();
        a.setTheme(dark ? R.style.CalendarDark : R.style.CalendarLight);
        a.getTheme().applyStyle(accentStyle(Cfg.accent()), true);
        a.getWindow().setStatusBarColor(bg());
        a.getWindow().setNavigationBarColor(bg());
        a.getWindow().getDecorView().setSystemUiVisibility(
                dark ? 0 : android.view.View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
    }

    private static int accentStyle(int i) {
        switch (i < 0 || i >= ACCENTS.length ? 0 : i) {
            case 1: return R.style.AccentAmethyst;
            case 2: return R.style.AccentIndigo;
            case 3: return R.style.AccentTeal;
            case 4: return R.style.AccentRose;
            case 5: return R.style.AccentCoral;
            case 6: return R.style.AccentEmerald;
            case 7: return R.style.AccentAmber;
            default: return R.style.AccentGold;
        }
    }
}
