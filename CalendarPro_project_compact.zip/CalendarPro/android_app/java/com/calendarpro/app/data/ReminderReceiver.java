package com.calendarpro.app.data;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

import com.calendarpro.app.R;
import com.calendarpro.app.ui.MainActivity;

import java.util.List;

public class ReminderReceiver extends BroadcastReceiver {

    private static final String CH = "calendarpro_daily";

    @Override
    public void onReceive(Context c, Intent intent) {
        if (!Cfg.remind()) return;
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return;

        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel(CH, "یادآور تقویم",
                    NotificationManager.IMPORTANCE_DEFAULT);
            ch.setDescription("یادآور رویدادها و تعطیلات روز");
            nm.createNotificationChannel(ch);
        }

        long today = Cal.todayJdn();
        List<Event> ev = Store.forJdn(today);
        List<String> hol = Holidays.forJdn(today);

        StringBuilder body = new StringBuilder();
        body.append(Cal.format(Cal.JALALI, today));
        if (!hol.isEmpty()) body.append(" — ").append(hol.get(0));
        if (ev.isEmpty()) {
            body.append("\nامروز رویدادی ثبت نشده است.");
        } else {
            for (Event e : ev) {
                body.append("\n• ").append(e.allDay() ? "" : (com.calendarpro.app.util.Fmt.clock(e.minutes) + " "));
                body.append(e.title);
            }
        }

        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= 23) flags |= PendingIntent.FLAG_IMMUTABLE;
        PendingIntent tap = PendingIntent.getActivity(c, 0,
                new Intent(c, MainActivity.class), flags);

        Notification.Builder b;
        if (Build.VERSION.SDK_INT >= 26) b = new Notification.Builder(c, CH);
        else b = new Notification.Builder(c);
        b.setSmallIcon(R.drawable.ic_calendar)
                .setContentTitle("تقویم پرو")
                .setContentText(body.toString())
                .setStyle(new Notification.BigTextStyle().bigText(body.toString()))
                .setContentIntent(tap)
                .setAutoCancel(true);

        try {
            nm.notify(101, b.build());
        } catch (Exception ignored) {
        }
    }
}
