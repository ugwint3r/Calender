package com.calendarpro.app.data;

import com.calendarpro.app.App;

public final class Cfg {
    private Cfg() {}

    // theme: 0 = dark, 1 = light, 2 = follow system
    public static int theme() { return App.p.getInt("theme", 0); }
    public static void theme(int v) { App.p.edit().putInt("theme", v).apply(); }

    public static int accent() { return App.p.getInt("accent", 0); }
    public static void accent(int v) { App.p.edit().putInt("accent", v).apply(); }

    // digits: 0 = Persian ۰۱۲, 1 = Latin 012
    public static int digits() { return App.p.getInt("digits", 0); }
    public static void digits(int v) { App.p.edit().putInt("digits", v).apply(); }

    // primary calendar for the month grid (see Cal.SYS_*)
    public static int primaryCal() { return App.p.getInt("primary_cal", Cal.JALALI); }
    public static void primaryCal(int v) { App.p.edit().putInt("primary_cal", v).apply(); }

    // secondary calendars shown as small numbers on day cells
    public static boolean secondary() { return App.p.getBoolean("secondary", true); }
    public static void secondary(boolean v) { App.p.edit().putBoolean("secondary", v).apply(); }

    // hijri manual adjustment (-2..+2 days) used for holiday accuracy
    public static int hijriOffset() { return App.p.getInt("hijri_offset", 0); }
    public static void hijriOffset(int v) { App.p.edit().putInt("hijri_offset", v).apply(); }

    // week starts on Saturday by default; option to start on Sunday/Monday
    public static int weekStart() { return App.p.getInt("week_start", 0); }
    public static void weekStart(int v) { App.p.edit().putInt("week_start", v).apply(); }

    // render the subtle top-glow background
    public static boolean glow() { return App.p.getBoolean("glow", true); }
    public static void glow(boolean v) { App.p.edit().putBoolean("glow", v).apply(); }

    // holiday markers on the grid
    public static boolean showHolidays() { return App.p.getBoolean("show_holidays", true); }
    public static void showHolidays(boolean v) { App.p.edit().putBoolean("show_holidays", v).apply(); }

    // reminders
    public static boolean remind() { return App.p.getBoolean("notify", false); }
    public static void remind(boolean v) { App.p.edit().putBoolean("notify", v).apply(); }
    public static int notifyHour() { return App.p.getInt("notify_hour", 8); }
    public static int notifyMinute() { return App.p.getInt("notify_min", 30); }
    public static void notifyTime(int h, int m) {
        App.p.edit().putInt("notify_hour", h).putInt("notify_min", m).apply();
    }

    public static int lastCal() { return App.p.getInt("last_cal", Cal.JALALI); }
    public static void lastCal(int v) { App.p.edit().putInt("last_cal", v).apply(); }

    public static void reset() {
        App.p.edit().clear().apply();
    }
}
