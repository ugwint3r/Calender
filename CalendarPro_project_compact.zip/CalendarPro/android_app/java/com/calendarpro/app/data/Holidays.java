package com.calendarpro.app.data;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** Official Iranian (solar + lunar) holidays and a few global observances. */
public final class Holidays {
    private Holidays() {}

    private static final Map<String, String> JALALI = new HashMap<>();
    private static final Map<String, String> HIJRI = new HashMap<>();
    private static final Map<String, String> GREG = new HashMap<>();

    static {
        JALALI.put("1-1", "جشن نوروز");
        JALALI.put("1-2", "نوروز");
        JALALI.put("1-3", "نوروز");
        JALALI.put("1-4", "نوروز");
        JALALI.put("1-12", "روز جمهوری اسلامی ایران");
        JALALI.put("1-13", "روز طبیعت (سیزده‌به‌در)");
        JALALI.put("3-14", "رحلت حضرت امام خمینی");
        JALALI.put("3-15", "قیام ۱۵ خرداد");
        JALALI.put("11-22", "پیروزی انقلاب اسلامی");
        JALALI.put("12-29", "روز ملی صنعت نفت");

        HIJRI.put("1-9", "تاسوعای حسینی");
        HIJRI.put("1-10", "عاشورای حسینی");
        HIJRI.put("2-20", "اربعین حسینی");
        HIJRI.put("2-28", "رحلت پیامبر اکرم و شهادت امام حسن مجتبی");
        HIJRI.put("3-8", "شهادت امام حسن عسکری");
        HIJRI.put("3-12", "میلاد پیامبر اکرم و امام صادق");
        HIJRI.put("3-17", "میلاد پیامبر اکرم (اهل سنت)");
        HIJRI.put("6-3", "شهادت حضرت فاطمه زهرا");
        HIJRI.put("7-13", "ولادت امام علی و روز پدر");
        HIJRI.put("7-27", "مبعث پیامبر اکرم");
        HIJRI.put("8-15", "ولادت حضرت قائم (عج)");
        HIJRI.put("9-21", "شهادت حضرت علی");
        HIJRI.put("10-1", "عید سعید فطر");
        HIJRI.put("10-25", "شهادت امام جعفر صادق");
        HIJRI.put("12-10", "عید سعید قربان");
        HIJRI.put("12-18", "عید سعید غدیر خم");

        GREG.put("1-1", "آغاز سال نو میلادی");
        GREG.put("5-1", "روز جهانی کارگر");
        GREG.put("12-25", "کریسمس");
    }

    public static boolean friday(long jdn) { return Cal.week(jdn) == 6; }

    public static List<String> forJdn(long jdn) {
        List<String> out = new ArrayList<>();
        int[] g = Cal.jdnToGreg(jdn);
        int[] j = Cal.jdnToJalali(jdn);
        int[] h = Cal.jdnToHijri(jdn + Cfg.hijriOffset());

        String s = GREG.get(g[1] + "-" + g[2]);
        if (s != null) out.add(s);
        s = JALALI.get(j[1] + "-" + j[2]);
        if (s != null) out.add(s);
        s = HIJRI.get(h[1] + "-" + h[2]);
        if (s != null) out.add(s);
        return out;
    }

    public static boolean isHoliday(long jdn) {
        return !forJdn(jdn).isEmpty();
    }

    /** true when the day should be styled red on the grid. */
    public static boolean red(long jdn) {
        return friday(jdn) || isHoliday(jdn);
    }

    public static String firstTitle(long jdn) {
        List<String> l = forJdn(jdn);
        if (friday(jdn) && l.isEmpty()) return "جمعه (تعطیل)";
        return l.isEmpty() ? null : l.get(0);
    }
}
