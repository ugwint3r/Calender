package com.calendarpro.app.data;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

/**
 * Calendar engine. All conversions route through the Julian Day Number (JDN).
 *
 * Grid calendars (with real month lengths):
 *   0 Gregorian  میلادی
 *   1 Jalali     هجری شمسی
 *   2 Hijri      هجری قمری
 *   3 Julian     یولیانی
 *   4 Hebrew     عبری
 *   5 Coptic     قبطی
 */
public final class Cal {
    private Cal() {}

    public static final int GREGORIAN = 0, JALALI = 1, HIJRI = 2, JULIAN = 3, HEBREW = 4, COPTIC = 5;
    public static final int[] PRIMARY = {JALALI, GREGORIAN, HIJRI, JULIAN, HEBREW, COPTIC};

    public static final String[] WEEK = {
            "شنبه", "یکشنبه", "دوشنبه", "سه‌شنبه", "چهارشنبه", "پنجشنبه", "جمعه"};
    public static final String[] WEEK_SHORT = {"ش", "ی", "د", "س", "چ", "پ", "ج"};

    private static final String[] M_GREG = {
            "ژانویه", "فوریه", "مارس", "آوریل", "مه", "ژوئن",
            "ژوئیه", "اوت", "سپتامبر", "اکتبر", "نوامبر", "دسامبر"};
    public static final String[] M_JALALI = {
            "فروردین", "اردیبهشت", "خرداد", "تیر", "مرداد", "شهریور",
            "مهر", "آبان", "آذر", "دی", "بهمن", "اسفند"};
    public static final String[] M_HIJRI = {
            "محرم", "صفر", "ربیع‌الاول", "ربیع‌الثانی", "جمادی‌الاول", "جمادی‌الثانی",
            "رجب", "شعبان", "رمضان", "شوال", "ذی‌القعده", "ذی‌الحجه"};
    private static final String[] M_HEBREW = {
            "", "نیسان", "ایار", "سیوان", "تموز", "آو", "ایلول",
            "تیشری", "حشوان", "کیسلو", "طبت", "شبات", "آدار", "آدار۲"};
    private static final String[] M_COPTIC = {
            "توت", "بابه", "هاتور", "کیاک", "طوبه", "امشیر", "برمهات",
            "برموده", "بشنس", "پائونی", "اییپ", "مسری", "نسئ"};

    public static String sysName(int sys) {
        switch (sys) {
            case GREGORIAN: return "میلادی";
            case JALALI: return "هجری شمسی";
            case HIJRI: return "هجری قمری";
            case JULIAN: return "یولیانی";
            case HEBREW: return "عبری";
            case COPTIC: return "قبطی";
            default: return "?";
        }
    }

    public static String sysShort(int sys) {
        switch (sys) {
            case GREGORIAN: return "میلادی";
            case JALALI: return "شمسی";
            case HIJRI: return "قمری";
            case JULIAN: return "یولیانی";
            case HEBREW: return "عبری";
            case COPTIC: return "قبطی";
            default: return "?";
        }
    }

    public static int firstMonth(int sys) { return sys == HEBREW ? 7 : 1; }

    public static int monthsInYear(int sys, int y) {
        if (sys == HEBREW) return hebrewLeap(y) ? 13 : 12;
        if (sys == COPTIC) return 13;
        return 12;
    }

    public static String monthName(int sys, int m) {
        switch (sys) {
            case GREGORIAN:
            case JULIAN: return M_GREG[clamp(m, 1, 12) - 1];
            case JALALI: return M_JALALI[clamp(m, 1, 12) - 1];
            case HIJRI: return M_HIJRI[clamp(m, 1, 12) - 1];
            case HEBREW: return M_HEBREW[clamp(m, 1, 13)];
            case COPTIC: return M_COPTIC[clamp(m, 1, 13) - 1];
            default: return "?";
        }
    }

    private static int clamp(int v, int lo, int hi) { return v < lo ? lo : (v > hi ? hi : v); }

    // ------------------------------------------------------------------ weekday

    /** 0 = شنبه (Saturday) ... 6 = جمعه (Friday). */
    public static int week(long jdn) {
        return (int) (((jdn % 7) + 9) % 7);
    }

    // ================================================================== GREGORIAN

    public static long gregToJdn(int y, int m, int d) {
        long a = (14 - m) / 12;
        long y2 = y + 4800 - a;
        long m2 = m + 12 * a - 3;
        return d + (153 * m2 + 2) / 5 + 365 * y2 + y2 / 4 - y2 / 100 + y2 / 400 - 32045;
    }

    public static int[] jdnToGreg(long jdn) {
        long a = jdn + 32044;
        long b = (4 * a + 3) / 146097;
        long c = a - (146097 * b) / 4;
        long d2 = (4 * c + 3) / 1461;
        long e = c - (1461 * d2) / 4;
        long m2 = (5 * e + 2) / 153;
        int day = (int) (e - (153 * m2 + 2) / 5 + 1);
        int month = (int) (m2 + 3 - 12 * (m2 / 10));
        int year = (int) (100 * b + d2 - 4800 + m2 / 10);
        return new int[]{year, month, day};
    }

    public static boolean gregLeap(int y) { return (y % 4 == 0 && y % 100 != 0) || y % 400 == 0; }

    // ================================================================== JULIAN

    public static long julianToJdn(int y, int m, int d) {
        long a = (14 - m) / 12;
        long y2 = y + 4800 - a;
        long m2 = m + 12 * a - 3;
        return d + (153 * m2 + 2) / 5 + 365 * y2 + y2 / 4 - 32083;
    }

    public static int[] jdnToJulian(long jdn) {
        long c = jdn + 32082;
        long d2 = (4 * c + 3) / 1461;
        long e = c - (1461 * d2) / 4;
        long m2 = (5 * e + 2) / 153;
        int day = (int) (e - (153 * m2 + 2) / 5 + 1);
        int month = (int) (m2 + 3 - 12 * (m2 / 10));
        int year = (int) (d2 - 4800 + m2 / 10);
        return new int[]{year, month, day};
    }

    // ================================================================== JALALI

    private static final int[] JBREAKS = {
            -61, 9, 38, 199, 426, 686, 756, 818, 1111, 1181, 1210, 1635,
            2060, 2097, 2192, 2262, 2324, 2394, 2456, 3178};

    private static long fdiv(long a, long b) { return Math.floorDiv(a, b); }
    private static long fmod(long a, long b) { return Math.floorMod(a, b); }

    /** returns {leap, gy, march} */
    private static int[] jalCal(int jy) {
        int bl = JBREAKS.length;
        int gy = jy + 621;
        int leapJ = -14;
        int jp = JBREAKS[0];
        int jump = 0;
        for (int i = 1; i < bl; i++) {
            int jm = JBREAKS[i];
            jump = jm - jp;
            if (jy < jm) break;
            leapJ = (int) (leapJ + fdiv(jump, 33) * 8 + fdiv(fmod(jump, 33), 4));
            jp = jm;
        }
        int n = jy - jp;
        leapJ = (int) (leapJ + fdiv(n, 33) * 8 + fdiv(fmod(n, 33) + 3, 4));
        if (fmod(jump, 33) == 4 && jump - n == 4) leapJ += 1;
        int leapG = (int) (fdiv(gy, 4) - fdiv((fdiv(gy, 100) + 1) * 3, 4) - 150);
        int march = 20 + leapJ - leapG;
        if (jump - n < 6) n = (int) (n - jump + fdiv(jump + 4, 33) * 33);
        int leap = (int) fmod(fmod(n + 1, 33) - 1, 4);
        if (leap == -1) leap = 4;
        return new int[]{leap, gy, march};
    }

    public static boolean jalaliLeap(int jy) { return jalCal(jy)[0] == 0; }

    public static long jalaliToJdn(int jy, int jm, int jd) {
        int[] r = jalCal(jy);
        return gregToJdn(r[1], 3, r[2]) + (jm - 1) * 31L - fdiv(jm, 7) * (jm - 7) + jd - 1;
    }

    public static int[] jdnToJalali(long jdn) {
        int gy = jdnToGreg(jdn)[0];
        int jy = gy - 621;
        int[] r = jalCal(jy);
        long jdn1f = gregToJdn(gy, 3, r[2]);
        long k = jdn - jdn1f;
        if (k >= 0) {
            if (k <= 185) {
                int jm = (int) (1 + fdiv(k, 31));
                int jd = (int) (fmod(k, 31) + 1);
                return new int[]{jy, jm, jd};
            } else {
                k -= 186;
            }
        } else {
            jy -= 1;
            k += 179;
            if (r[0] == 1) k += 1;
        }
        int jm = (int) (7 + fdiv(k, 30));
        int jd = (int) (fmod(k, 30) + 1);
        return new int[]{jy, jm, jd};
    }

    // ================================================================== HIJRI

    public static long hijriToJdn(int y, int m, int d) {
        return d + (long) Math.ceil(29.5 * (m - 1)) + (long) (y - 1) * 354
                + (long) Math.floor((3 + 11L * y) / 30.0) + 1948439 - 1;
    }

    public static int[] jdnToHijri(long jdn) {
        long y = (long) Math.floor((30.0 * (jdn - 1948439) + 10646) / 10631.0);
        int m = (int) Math.min(12, Math.ceil((jdn - (29 + hijriToJdn((int) y, 1, 1))) / 29.5) + 1);
        int d = (int) (jdn - hijriToJdn((int) y, m, 1) + 1);
        return new int[]{(int) y, m, d};
    }

    // ================================================================== HEBREW

    private static final long HEBREW_EPOCH_JDN = 347998L;

    public static boolean hebrewLeap(long y) { return fmod(7 * y + 1, 19) < 7; }

    private static long hebrewElapsedDays(long year) {
        long monthsElapsed = 235 * ((year - 1) / 19) + 12 * ((year - 1) % 19)
                + (7 * ((year - 1) % 19) + 1) / 19;
        long partsElapsed = 204 + 793 * (monthsElapsed % 1080);
        long hoursElapsed = 5 + 12 * monthsElapsed + 793 * (monthsElapsed / 1080) + partsElapsed / 1080;
        long day = 1 + 29 * monthsElapsed + hoursElapsed / 24;
        long parts = (hoursElapsed % 24) * 1080 + partsElapsed % 1080;
        long alt;
        if (parts >= 19440
                || ((day % 7) == 2 && parts >= 9924 && !hebrewLeap(year))
                || ((day % 7) == 1 && parts >= 16789 && hebrewLeap(year - 1))) {
            alt = day + 1;
        } else {
            alt = day;
        }
        if ((alt % 7) == 0 || (alt % 7) == 3 || (alt % 7) == 5) alt += 1;
        return alt;
    }

    private static long hebrewYearDays(long y) { return hebrewElapsedDays(y + 1) - hebrewElapsedDays(y); }

    private static int hebrewMonthDays(long year, int month) {
        if (month == 2 || month == 4 || month == 6 || month == 10 || month == 13) return 29;
        if (month == 12 && !hebrewLeap(year)) return 29;
        if (month == 8 && (hebrewYearDays(year) % 10) != 5) return 29;
        if (month == 9 && (hebrewYearDays(year) % 10) == 3) return 29;
        return 30;
    }

    public static long hebrewToJdn(long year, int month, int day) {
        long jdn = HEBREW_EPOCH_JDN + hebrewElapsedDays(year) + day - 1;
        if (month < 7) {
            int last = hebrewLeap(year) ? 13 : 12;
            for (int m = 7; m <= last; m++) jdn += hebrewMonthDays(year, m);
            for (int m = 1; m < month; m++) jdn += hebrewMonthDays(year, m);
        } else {
            for (int m = 7; m < month; m++) jdn += hebrewMonthDays(year, m);
        }
        return jdn;
    }

    public static int[] jdnToHebrew(long jdn) {
        long year = fdiv((jdn - HEBREW_EPOCH_JDN) * 98496L, 35975351L) + 1;
        while (hebrewToJdn(year + 1, 7, 1) <= jdn) year++;
        while (hebrewToJdn(year, 7, 1) > jdn) year--;
        int last = hebrewLeap(year) ? 13 : 12;
        int month = 7;
        int[] order = {7, 8, 9, 10, 11, 12, 13, 1, 2, 3, 4, 5, 6};
        for (int mm : order) {
            if (mm > last) continue;
            if (hebrewToJdn(year, mm, 1) <= jdn) month = mm;
        }
        int day = (int) (jdn - hebrewToJdn(year, month, 1) + 1);
        return new int[]{(int) year, month, day};
    }

    // ================================================================== COPTIC

    public static long copticToJdn(int y, int m, int d) {
        return 1825030L + 365L * (y - 1) + (y / 4) + 30L * (m - 1) + (d - 1);
    }

    public static int[] jdnToCoptic(long jdn) {
        long d = jdn - 1825030L;
        int y = (int) ((d * 4 + 1463) / 1461 + 1);
        while (copticToJdn(y, 1, 1) > jdn) y--;
        while (copticToJdn(y + 1, 1, 1) <= jdn) y++;
        long yd = jdn - copticToJdn(y, 1, 1);
        int m = (int) (yd / 30 + 1);
        int day = (int) (yd % 30 + 1);
        return new int[]{y, m, day};
    }

    // ================================================================== generic API

    public static long toJdn(int sys, int y, int m, int d) {
        switch (sys) {
            case GREGORIAN: return gregToJdn(y, m, d);
            case JULIAN: return julianToJdn(y, m, d);
            case JALALI: return jalaliToJdn(y, m, d);
            case HIJRI: return hijriToJdn(y, m, d) - Cfg.hijriOffset();
            case HEBREW: return hebrewToJdn(y, m, d);
            case COPTIC: return copticToJdn(y, m, d);
            default: return gregToJdn(y, m, d);
        }
    }

    public static int[] fromJdn(int sys, long jdn) {
        switch (sys) {
            case GREGORIAN: return jdnToGreg(jdn);
            case JULIAN: return jdnToJulian(jdn);
            case JALALI: return jdnToJalali(jdn);
            case HIJRI: return jdnToHijri(jdn + Cfg.hijriOffset());
            case HEBREW: return jdnToHebrew(jdn);
            case COPTIC: return jdnToCoptic(jdn);
            default: return jdnToGreg(jdn);
        }
    }

    public static int daysInMonth(int sys, int y, int m) {
        if (sys == HEBREW) return hebrewMonthDays(y, m);
        int first = firstMonth(sys);
        long a = toJdn(sys, y, m, 1);
        long b;
        if (m < monthsInYear(sys, y)) b = toJdn(sys, y, m + 1, 1);
        else b = toJdn(sys, y + 1, first, 1);
        return (int) (b - a);
    }

    // ================================================================== key dates

    public static long todayJdn() {
        Calendar c = Calendar.getInstance();
        return gregToJdn(c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1, c.get(Calendar.DAY_OF_MONTH));
    }

    public static int[] todayJalali() { return jdnToJalali(todayJdn()); }

    /** format "d MONTH y" for a system, digits obey the settings. */
    public static String format(int sys, long jdn) {
        int[] a = fromJdn(sys, jdn);
        return com.calendarpro.app.util.Fmt.num(a[2]) + " " + monthName(sys, a[1]) + " " + com.calendarpro.app.util.Fmt.num(a[0]);
    }

    public static String formatShort(int sys, long jdn) {
        int[] a = fromJdn(sys, jdn);
        return com.calendarpro.app.util.Fmt.num(a[2]) + " " + monthName(sys, a[1]);
    }

    /** full title used for month headers, e.g. "مهر ۱۴۰۵". */
    public static String monthTitle(int sys, int y, int m) {
        return monthName(sys, m) + " " + com.calendarpro.app.util.Fmt.num(y);
    }

    // ================================================================== eras

    /** Returns the day rendered across many world calendars / eras. */
    public static List<String[]> eras(long jdn) {
        List<String[]> out = new ArrayList<>();
        int[] g = jdnToGreg(jdn);
        int[] j = jdnToJalali(jdn);
        int[] h = jdnToHijri(jdn + Cfg.hijriOffset());
        int[] ju = jdnToJulian(jdn);
        int[] hb = jdnToHebrew(jdn);
        int[] cp = jdnToCoptic(jdn);

        out.add(new String[]{"میلادی (گرگوری)", g[2] + " " + M_GREG[g[1] - 1] + " " + g[0]});
        out.add(new String[]{"هجری شمسی (جلالی)", j[2] + " " + M_JALALI[j[1] - 1] + " " + j[0]});
        out.add(new String[]{"هجری قمری", h[2] + " " + M_HIJRI[h[1] - 1] + " " + h[0]});
        out.add(new String[]{"یولیانی (ژولینی)", ju[2] + " " + M_GREG[ju[1] - 1] + " " + ju[0]});
        out.add(new String[]{"عبری", hb[2] + " " + M_HEBREW[hb[1]] + " " + hb[0]});
        out.add(new String[]{"قبطی", cp[2] + " " + M_COPTIC[cp[1] - 1] + " " + cp[0]});

        out.add(new String[]{"بودایی", String.valueOf(g[0] + 543)});
        out.add(new String[]{"مینگو (تایوان)", String.valueOf(g[0] - 1911)});
        out.add(new String[]{"کالی یوگا", String.valueOf(g[0] + 3101)});
        out.add(new String[]{"یزدگردی (زرتشتی)", String.valueOf(g[0] - 631)});

        int animal = (int) fmod(g[0] - 4, 12);
        String[] zoo = {"موش", "گاو", "ببر", "خرگوش", "اژدها", "مار", "اسب", "بز", "میمون", "خروس", "سگ", "خوک"};
        int cyc = (int) fmod(g[0] - 4, 60) + 1;
        out.add(new String[]{"گاه‌شماری چینی", zoo[animal] + " • چرخهٔ " + cyc});

        out.add(new String[]{"گاه‌شماری ژاپنی", japaneseEra(jdn, g[0])});

        int[] my = maya(jdn);
        out.add(new String[]{"مایا (شمارش بلند)", my[0] + "." + my[1] + "." + my[2] + "." + my[3] + "." + my[4]});

        out.add(new String[]{"شمارهٔ روز ژولیوسی", String.valueOf(jdn)});
        out.add(new String[]{"شمارهٔ روز یونیکس", String.valueOf(jdn - 2440588L)});
        out.add(new String[]{"روز سال (میلادی)", String.valueOf(dayOfYearGreg(jdn))});
        return out;
    }

    private static int dayOfYearGreg(long jdn) {
        int[] g = jdnToGreg(jdn);
        return (int) (jdn - gregToJdn(g[0], 1, 1) + 1);
    }

    public static int[] maya(long jdn) {
        long d = jdn - 584283L;
        int baktun = (int) (d / 144000); d %= 144000;
        int katun = (int) (d / 7200); d %= 7200;
        int tun = (int) (d / 360); d %= 360;
        int uinal = (int) (d / 20);
        int kin = (int) (d % 20);
        return new int[]{baktun, katun, tun, uinal, kin};
    }

    private static String japaneseEra(long jdn, int gy) {
        String[] names = {"ریوا", "هیسی", "شووا", "تایشو", "میجی"};
        long[] starts = {
                gregToJdn(2019, 5, 1), gregToJdn(1989, 1, 8), gregToJdn(1926, 12, 25),
                gregToJdn(1912, 7, 30), gregToJdn(1868, 10, 23)};
        int[] base = {2018, 1988, 1925, 1911, 1867};
        for (int i = 0; i < starts.length; i++) {
            if (jdn >= starts[i]) {
                int yr = gy - base[i];
                return names[i] + " " + yr + (yr == 1 ? " (نخست)" : "");
            }
        }
        return String.valueOf(gy);
    }

    public static int abs(int v) { return v < 0 ? -v : v; }
}
