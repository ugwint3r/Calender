package com.calendarpro.app.data;

public class Event {
    public long id;
    public long jdn;
    public int minutes; // -1 = all day
    public int color;   // accent palette index
    public String title;
    public String note;

    public Event() {}

    public Event(long jdn, int minutes, int color, String title, String note) {
        this.id = System.nanoTime();
        this.jdn = jdn;
        this.minutes = minutes;
        this.color = color;
        this.title = title == null ? "" : title;
        this.note = note == null ? "" : note;
    }

    public boolean allDay() { return minutes < 0; }

    public String encode() {
        return id + "|" + jdn + "|" + minutes + "|" + color + "|"
                + clean(title) + "|" + clean(note);
    }

    public static Event decode(String line) {
        String[] p = line.split("\\|", -1);
        if (p.length < 6) return null;
        try {
            Event e = new Event();
            e.id = Long.parseLong(p[0]);
            e.jdn = Long.parseLong(p[1]);
            e.minutes = Integer.parseInt(p[2]);
            e.color = Integer.parseInt(p[3]);
            e.title = p[4];
            e.note = p[5];
            return e;
        } catch (Exception ex) {
            return null;
        }
    }

    private static String clean(String s) {
        if (s == null) return "";
        return s.replace("|", " ").replace("\n", " ").replace("\r", " ").trim();
    }
}
