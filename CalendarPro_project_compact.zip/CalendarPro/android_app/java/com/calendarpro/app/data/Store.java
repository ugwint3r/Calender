package com.calendarpro.app.data;

import com.calendarpro.app.App;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public final class Store {
    private Store() {}

    private static final String KEY = "events_v1";

    public static List<Event> all() {
        List<Event> out = new ArrayList<>();
        String raw = App.p.getString(KEY, "");
        if (raw == null || raw.isEmpty()) return out;
        for (String line : raw.split("\n")) {
            if (line.trim().isEmpty()) continue;
            Event e = Event.decode(line);
            if (e != null) out.add(e);
        }
        Collections.sort(out, new Comparator<Event>() {
            public int compare(Event a, Event b) {
                if (a.jdn != b.jdn) return a.jdn < b.jdn ? -1 : 1;
                return Integer.compare(a.minutes, b.minutes);
            }
        });
        return out;
    }

    private static void write(List<Event> list) {
        StringBuilder sb = new StringBuilder();
        for (Event e : list) {
            if (sb.length() > 0) sb.append('\n');
            sb.append(e.encode());
        }
        App.p.edit().putString(KEY, sb.toString()).apply();
    }

    public static List<Event> forJdn(long jdn) {
        List<Event> out = new ArrayList<>();
        for (Event e : all()) if (e.jdn == jdn) out.add(e);
        return out;
    }

    public static int countForJdn(long jdn) { return forJdn(jdn).size(); }

    public static void add(Event e) {
        List<Event> list = all();
        list.add(e);
        write(list);
    }

    public static void update(Event e) {
        List<Event> list = all();
        for (int i = 0; i < list.size(); i++) {
            if (list.get(i).id == e.id) { list.set(i, e); break; }
        }
        write(list);
    }

    public static void delete(long id) {
        List<Event> list = all();
        for (int i = list.size() - 1; i >= 0; i--) {
            if (list.get(i).id == id) list.remove(i);
        }
        write(list);
    }

    public static Event byId(long id) {
        for (Event e : all()) if (e.id == id) return e;
        return null;
    }

    public static List<Event> upcoming(long fromJdn, int limit) {
        List<Event> out = new ArrayList<>();
        for (Event e : all()) {
            if (e.jdn >= fromJdn) out.add(e);
            if (out.size() >= limit) break;
        }
        return out;
    }
}
