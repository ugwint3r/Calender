package com.calendarpro.app;

import android.app.Application;
import android.content.SharedPreferences;

public class App extends Application {
    public static App I;
    public static SharedPreferences p;
    public static int appliedTheme = -1;
    public static int appliedAccent = -1;
    public static int appliedDigits = -1;

    @Override
    public void onCreate() {
        super.onCreate();
        I = this;
        p = getSharedPreferences("calendarpro", MODE_PRIVATE);
    }
}
