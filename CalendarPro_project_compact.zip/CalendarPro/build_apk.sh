#!/usr/bin/env bash
# CalendarPro - build a signed Android APK without Gradle.
# aapt2(res) -> aapt2(link+R.java) -> javac -> d8 -> bundle -> zipalign -> apksigner
set -uo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
APP="$ROOT/android_app"
BUILD="$ROOT/.build"
DIST="$ROOT/dist"
TOOLS="${CALENDARPRO_TOOLS:-/opt/tools}"

APP_NAME="CalendarPro"
VERSION_CODE=1
VERSION_NAME="1.0"
MIN_SDK=24
TARGET_SDK=33

ANDROID_JAR="${ANDROID_JAR:-/opt/android-sdk/platforms/android-28/android.jar}"
R8_JAR="${R8_JAR:-$TOOLS/r8.jar}"

find_jdk() {
  for d in "$@"; do
    [ -n "${d:-}" ] && [ -x "$d/bin/java" ] && "$d/bin/java" -version >/dev/null 2>&1 && { echo "$d"; return 0; }
  done
  return 1
}
JDK17="$(find_jdk "${JAVA_HOME:-}" /usr/lib/jvm/java-17-openjdk-arm64 /usr/lib/jvm/java-17-openjdk-* /usr/lib/jvm/java-21-openjdk-* /usr/lib/jvm/default-java)"
JDK8="$(find_jdk /usr/lib/jvm/java-8-openjdk-arm64 /usr/lib/jvm/java-1.8.0-openjdk-arm64 /usr/lib/jvm/java-8-openjdk-* /usr/lib/jvm/java-1.8.0-openjdk-*)"
[ -z "$JDK17" ] && { echo "ERROR: no JDK 17 found"; exit 1; }
[ -z "$JDK8" ]  && JDK8="$JDK17"
JAVA="$JDK17/bin/java"
JAVAC="$JDK8/bin/javac"
KEYTOOL="$JDK17/bin/keytool"
export JAVA_HOME="$JDK17"
export PATH="$JDK17/bin:$PATH"

AAPT2="$(command -v aapt2 || echo /usr/bin/aapt2)"
ZIPALIGN="$(command -v zipalign || echo /usr/bin/zipalign)"
APKSIGNER="$(command -v apksigner || echo /usr/bin/apksigner)"

echo "==> javac  : $JAVAC"
echo "==> android.jar: $ANDROID_JAR"

rm -rf "$BUILD"
python3 -c 'import os,sys
for p in sys.argv[1:]: os.makedirs(p, exist_ok=True)' \
  "$DIST" "$BUILD/classes" "$BUILD/dex" "$BUILD/apk" "$BUILD/rjava"

if [ ! -d "$APP/res/mipmap-mdpi" ]; then
  echo "==> [0/8] generating icons"
  python3 "$ROOT/tools/gen_icons.py" || { echo "icon generation failed"; exit 1; }
fi

echo "==> [1/8] aapt2 compile"
"$AAPT2" compile --dir "$APP/res" -o "$BUILD/res.zip" || exit 1

echo "==> [2/8] aapt2 link + R.java"
"$AAPT2" link \
  -o "$BUILD/apk/base.apk" \
  -I "$ANDROID_JAR" \
  --manifest "$APP/AndroidManifest.xml" \
  --min-sdk-version "$MIN_SDK" \
  --target-sdk-version "$TARGET_SDK" \
  --version-code "$VERSION_CODE" \
  --version-name "$VERSION_NAME" \
  --java "$BUILD/rjava" \
  "$BUILD/res.zip" || exit 1
echo "    R.java: $(find "$BUILD/rjava" -name 'R.java' | head -1)"

echo "==> [3/8] javac"
find "$APP/java" -name '*.java' > "$BUILD/sources.list"
find "$BUILD/rjava" -name '*.java' >> "$BUILD/sources.list"
JDK8_RT=""
for p in "$JDK8/jre/lib/rt.jar" "$JDK8/lib/rt.jar"; do [ -f "$p" ] && JDK8_RT="$p" && break; done
BOOT_CP="$ANDROID_JAR"; [ -n "$JDK8_RT" ] && BOOT_CP="$JDK8_RT:$ANDROID_JAR"
"$JAVAC" -source 1.8 -target 1.8 -encoding UTF-8 -nowarn \
  -bootclasspath "$BOOT_CP" -classpath "$ANDROID_JAR" \
  -d "$BUILD/classes" @"$BUILD/sources.list" 2> "$BUILD/javac.log"
if [ $? -ne 0 ]; then echo "JAVAC FAILED:"; cat "$BUILD/javac.log"; exit 1; fi
echo "    classes: $(find "$BUILD/classes" -name '*.class' | wc -l)"

echo "==> [4/8] d8 (dex)"
find "$BUILD/classes" -name '*.class' > "$BUILD/classes.list"
"$JAVA" -cp "$R8_JAR" com.android.tools.r8.D8 --release \
  --min-api "$MIN_SDK" --lib "$ANDROID_JAR" \
  --output "$BUILD/dex" @"$BUILD/classes.list" 2> "$BUILD/d8.log"
if [ $? -ne 0 ]; then echo "D8 FAILED:"; cat "$BUILD/d8.log"; exit 1; fi
ls -l "$BUILD/dex/classes.dex"

echo "==> [5/8] bundling assets + classes.dex"
python3 - "$BUILD/apk/base.apk" "$APP" "$BUILD/dex/classes.dex" "$BUILD/apk/full.apk" <<'PY' || exit 1
import os, sys, zipfile
base, appdir, dex, out = sys.argv[1:5]
STORE = {"resources.arsc", "AndroidManifest.xml", "classes.dex"}
z = zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED)
with zipfile.ZipFile(base) as bz:
    for name in bz.namelist():
        ct = zipfile.ZIP_STORED if name in STORE else zipfile.ZIP_DEFLATED
        z.writestr(name, bz.read(name), compress_type=ct)
for sub in ("assets", "lib"):
    root = os.path.join(appdir, sub)
    if os.path.isdir(root):
        for r, _, files in os.walk(root):
            for f in files:
                p = os.path.join(r, f)
                z.write(p, os.path.relpath(p, appdir), compress_type=zipfile.ZIP_DEFLATED)
z.write(dex, "classes.dex", compress_type=zipfile.ZIP_STORED)
z.close()
print("    wrote", out, os.path.getsize(out), "bytes")
PY

echo "==> [6/8] align + sign"
"$ZIPALIGN" -f -p 4 "$BUILD/apk/full.apk" "$BUILD/apk/aligned.apk" || exit 1
KS="$ROOT/keystore/calendarpro.keystore"
if [ ! -f "$KS" ]; then
  python3 -c 'import os;os.makedirs(os.path.dirname("'"$KS"'"),exist_ok=True)'
  "$KEYTOOL" -genkeypair -keystore "$KS" -alias calendarpro \
    -storepass calendar123 -keypass calendar123 -keyalg RSA -keysize 2048 \
    -validity 10000 -dname "CN=CalendarPro, O=CalendarPro, C=IR" >/dev/null 2>&1
  echo "    generated keystore: $KS"
fi
"$APKSIGNER" sign --ks "$KS" --ks-pass pass:calendar123 --key-pass pass:calendar123 \
  --v1-signing-enabled true --v2-signing-enabled true --v3-signing-enabled true \
  --out "$DIST/$APP_NAME.apk" "$BUILD/apk/aligned.apk" || exit 1

echo "==> [7/8] verify"
"$APKSIGNER" verify -v "$DIST/$APP_NAME.apk" 2>/dev/null | grep -iE "verified using" || true

echo "==> [8/8] aapt dump badging"
"$AAPT2" dump badging "$DIST/$APP_NAME.apk" 2>/dev/null | grep -E "package:|launchable-activity" || true
echo ""
echo "==> DONE: $DIST/$APP_NAME.apk ($(du -h "$DIST/$APP_NAME.apk" | cut -f1))"
